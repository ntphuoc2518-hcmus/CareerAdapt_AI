import json
import os
import tempfile
import unittest

from data_analyst_ai.attempt import grade_attempt, grade_question
from data_analyst_ai.audit import AuditLog
from data_analyst_ai.config import GradingError, LLMCallError
from data_analyst_ai.essay_grader import grade_essay
from data_analyst_ai.llm_layer import (aggregate_runs, parse_llm_json, score_b5_length, validate_result,
                                       question_ai_score)
from data_analyst_ai.question_bank import BEGINNER_QUESTIONS, QUESTIONS
from data_analyst_ai.review import ReviewQueue
from data_analyst_ai.rubrics import RUBRICS
from data_analyst_ai.sql_grader import REFERENCE_SQL
from data_analyst_ai.testing import MockLLM
from data_analyst_ai.text_utils import limit_words


def make_result(qid="A-T5", score=3, quote="trung bình", note=""):
    q = QUESTIONS[qid]
    r = RUBRICS[q.rubric_id]
    return {
        "question_id": qid, "rubric_id": r.id,
        "criteria": [{"id": c.id, "reason": "ok", "evidence_quote": quote, "score": score} for c in r.criteria],
        "flags": {"prompt_injection": False, "off_topic": False, "empty_or_too_short": False,
                  "copied_suspected": False, "evidence_fabricated": False, "note": note},
        "strengths": "a", "weaknesses": "b", "feedback_to_student": "c", "confidence": "high"}


def beginner_answers():
    answers = {}
    for qid in BEGINNER_QUESTIONS:
        q = QUESTIONS[qid]
        if q.kind == "mcq":
            answers[qid] = q.answer_option_id
        elif q.kind == "sql":
            answers[qid] = REFERENCE_SQL[qid]
        elif q.kind == "essay":
            answers[qid] = ("Trung bình bị kéo bởi giá trị lớn nên trung vị phù hợp hơn khi có ngoại lai; "
                            "ví dụ giá nhà hoặc thu nhập thường lệch phải. " * 3)
        else:
            answers[qid] = "Câu trả lời mẫu cho câu này. " * 10
    return answers


class ValidateTests(unittest.TestCase):
    ANSWER = "Tôi nghĩ trung bình bị ảnh hưởng bởi ngoại lai"

    def run_validate(self, result):
        r = RUBRICS["A1"]
        return validate_result(result, self.ANSWER, "A-T5", "A1", r.criterion_ids)

    def test_valid(self):
        out = self.run_validate(make_result(quote="trung bình bị ảnh hưởng"))
        self.assertTrue(all(c["score"] == 3 for c in out["criteria"]))

    def test_fabricated_quote_capped(self):
        out = self.run_validate(make_result(quote="câu này không có trong bài"))
        self.assertTrue(all(c["score"] <= 1 for c in out["criteria"]))
        self.assertTrue(out["flags"]["evidence_fabricated"])

    def test_empty_quote_capped(self):
        out = self.run_validate(make_result(quote=""))
        self.assertTrue(all(c["score"] <= 1 for c in out["criteria"]))

    def test_rejects_bad_scores(self):
        for bad in (4.5, True, 5, -1, "3"):
            res = make_result(quote="trung bình")
            res["criteria"][0]["score"] = bad
            with self.assertRaises(ValueError, msg=repr(bad)):
                self.run_validate(res)

    def test_rejects_extra_and_missing_fields(self):
        res = make_result(quote="trung bình")
        res["next_skill_codes"] = ["x"]
        with self.assertRaises(ValueError):
            self.run_validate(res)
        res = make_result(quote="trung bình")
        del res["confidence"]
        with self.assertRaises(ValueError):
            self.run_validate(res)

    def test_rejects_duplicate_or_unknown_criterion(self):
        res = make_result(quote="trung bình")
        res["criteria"][1]["id"] = res["criteria"][0]["id"]
        with self.assertRaises(ValueError):
            self.run_validate(res)

    def test_quote_over_25_words(self):
        with self.assertRaises(ValueError):
            self.run_validate(make_result(quote=" ".join(["từ"] * 26)))

    def test_parse_json_with_fence(self):
        self.assertEqual(parse_llm_json('```json\n{"a": 1}\n```'), {"a": 1})
        self.assertEqual(parse_llm_json('xin chào {"a": 1} hết'), {"a": 1})
        with self.assertRaises(ValueError):
            parse_llm_json("không có json")


class AggregateTests(unittest.TestCase):
    def test_median_and_low_confidence_on_spread(self):
        ids = RUBRICS["A1"].criterion_ids
        runs = [make_result(score=s) for s in (1, 3, 4)]
        out = aggregate_runs(runs, ids)
        self.assertTrue(all(c["score"] == 3 for c in out["criteria"]))
        self.assertEqual(out["confidence"], "low")          # range = 3 >= 2

    def test_flags_or_merged(self):
        ids = RUBRICS["A1"].criterion_ids
        runs = [make_result(score=3) for _ in range(3)]
        runs[1]["flags"]["prompt_injection"] = True
        self.assertTrue(aggregate_runs(runs, ids)["flags"]["prompt_injection"])

    def test_requires_three(self):
        with self.assertRaises(ValueError):
            aggregate_runs([make_result()], RUBRICS["A1"].criterion_ids)


class ScoringTests(unittest.TestCase):
    def test_b5_length_bands(self):
        n = lambda k: score_b5_length(" ".join(["w"] * k))
        self.assertEqual([n(0), n(19), n(20), n(40), n(119), n(120), n(139), n(140), n(160), n(161), n(200), n(201)],
                         [0, 1, 2, 4, 4, 3, 3, 2, 2, 1, 1, 0])

    def test_question_ai_score_bounds(self):
        ids = RUBRICS["A1"].criterion_ids
        self.assertEqual(question_ai_score("A1", {i: 4 for i in ids}), 100.0)
        self.assertEqual(question_ai_score("A1", {i: 0 for i in ids}), 0.0)
        with self.assertRaises(ValueError):
            question_ai_score("A1", {i: 5 for i in ids})

    def test_limit_words_preserves_layout(self):
        text, cut = limit_words("a b\n    c d\ne", 3)
        self.assertEqual((text, cut), ("a b\n    c", True))


class FlakyLLM(MockLLM):
    """Hỏng sau `fail_after` lần gọi."""
    def __init__(self, fail_after, exc=ConnectionError("boom secret-key-123"), **kw):
        super().__init__(**kw)
        self.fail_after, self.exc, self.n = fail_after, exc, 0

    def complete(self, system, user, **kw):
        self.n += 1
        if self.n > self.fail_after:
            raise self.exc
        return super().complete(system, user, **kw)


class EssayTests(unittest.TestCase):
    ANSWER = "Trung bình bị kéo lệch bởi ngoại lai nên dùng trung vị khi dữ liệu lệch. " * 3

    def test_default_is_one_call(self):
        llm = MockLLM()
        g = grade_essay(llm, QUESTIONS["A-T5"], self.ANSWER, audience="beginner")
        self.assertEqual((g.runs_used, len(llm.calls)), (1, 1))

    def test_extra_runs_reuse_prior_run(self):
        llm = MockLLM()
        first = grade_essay(llm, QUESTIONS["A-T5"], self.ANSWER, audience="beginner")
        grade_essay(llm, QUESTIONS["A-T5"], self.ANSWER, audience="beginner", extra_runs=True, prior_runs=first.runs)
        self.assertEqual(len(llm.calls), 3)                 # 1 + đúng 2 lượt bổ sung, không chấm lại lượt 1

    def test_network_error_becomes_grading_error_without_leaking_secret(self):
        with self.assertRaises(GradingError) as cm:
            grade_essay(FlakyLLM(0), QUESTIONS["A-T5"], self.ANSWER, audience="beginner")
        self.assertIsInstance(cm.exception, LLMCallError)
        self.assertNotIn("secret-key-123", str(cm.exception))

    def test_grade_question_marks_technical_error_instead_of_crashing(self):
        res, _ = grade_question(FlakyLLM(0), QUESTIONS["A-T5"], self.ANSWER, audience="beginner", role=None,
                                attempt_id="t", audit=AuditLog())
        self.assertIsNone(res.question_score)
        self.assertIn("technical_error", res.review_reasons)


class AttemptTests(unittest.TestCase):
    def test_beginner_attempt_end_to_end(self):
        att = grade_attempt(MockLLM(default_score=3), "beginner", beginner_answers(), attempt_id="e2e")
        self.assertIn("overall_score", att.assessment)
        self.assertIn(att.status, ("final", "provisional"))

    def test_llm_outage_does_not_crash_attempt(self):
        att = grade_attempt(FlakyLLM(0), "beginner", beginner_answers(), attempt_id="down")
        self.assertEqual(att.status, "provisional")
        self.assertTrue(any("technical_error" in r for r in att.review_reasons))

    def test_failed_regrade_keeps_first_score(self):
        # LLM chạy được 1 lượt/câu rồi hỏng: điểm lượt đầu phải được giữ, không biến thành None
        n_essays = sum(1 for q in BEGINNER_QUESTIONS if QUESTIONS[q].ai_share > 0)
        llm = FlakyLLM(n_essays, default_score=3)
        att = grade_attempt(llm, "beginner", beginner_answers(), attempt_id="regrade")
        for qid in BEGINNER_QUESTIONS:
            if QUESTIONS[qid].ai_share > 0:
                self.assertIsNotNone(att.questions[qid].question_score, qid)

    def test_forced_regrade_reuses_first_run_and_survives_failure(self):
        from unittest import mock
        n_essays = sum(1 for q in BEGINNER_QUESTIONS if QUESTIONS[q].ai_share > 0)
        with mock.patch("data_analyst_ai.attempt.near_decision_threshold", return_value=True):
            ok = MockLLM(default_score=3)
            att = grade_attempt(ok, "beginner", beginner_answers(), attempt_id="force")
            self.assertEqual(len(ok.calls), 3 * n_essays)          # đúng 3 lượt/câu, không tốn lượt thừa
            broken = FlakyLLM(n_essays, default_score=3)
            att2 = grade_attempt(broken, "beginner", beginner_answers(), attempt_id="force2")
        self.assertTrue(any("regrade_failed" in r for r in att2.review_reasons))
        for qid in BEGINNER_QUESTIONS:
            if QUESTIONS[qid].ai_share > 0:
                self.assertIsNotNone(att2.questions[qid].question_score)

    def test_unknown_question_rejected(self):
        with self.assertRaises(ValueError):
            grade_attempt(MockLLM(), "beginner", {"Z-999": "x"})


class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.audit = AuditLog()
        self.att = grade_attempt(MockLLM(default_score=2), "beginner", beginner_answers(), attempt_id="att-1")
        self.other = grade_attempt(MockLLM(default_score=2), "beginner", beginner_answers(), attempt_id="att-2")
        self.queue = ReviewQueue(self.audit)
        self.essay_qid = next(q for q in BEGINNER_QUESTIONS if QUESTIONS[q].ai_share > 0 and QUESTIONS[q].code_share == 0)
        self.cid = next(iter(self.att.questions[self.essay_qid].criterion_scores))

    def adjust(self, ticket, attempt=None, **kw):
        args = dict(ticket_id=ticket.ticket_id, attempt=attempt or self.att, question_id=self.essay_qid,
                    criterion_id=self.cid, new_score=4, reason="đúng ý", reviewer_id="r1")
        args.update(kw)
        return self.queue.resolve_adjustment(**args)

    def test_adjust_returns_new_attempt_and_does_not_mutate_input(self):
        t = self.queue.submit_appeal("att-1", self.essay_qid, [self.cid], "khiếu nại")
        before = self.att.questions[self.essay_qid].criterion_scores[self.cid]
        updated = self.adjust(t)
        self.assertEqual(self.att.questions[self.essay_qid].criterion_scores[self.cid], before)
        self.assertEqual(updated.questions[self.essay_qid].criterion_scores[self.cid], 4)
        self.assertEqual(self.queue.tickets[t.ticket_id].status, "resolved")
        self.assertTrue(any(e["event"] == "score_adjusted" for e in self.audit.events))

    def test_ticket_must_match_attempt(self):
        t = self.queue.submit_appeal("att-1", self.essay_qid, [], "x")
        with self.assertRaises(ValueError):
            self.adjust(t, attempt=self.other)

    def test_ticket_cannot_be_reused(self):
        t = self.queue.submit_appeal("att-1", self.essay_qid, [], "x")
        self.adjust(t)
        with self.assertRaises(ValueError):
            self.adjust(t)

    def test_appeal_limited_to_its_question_and_criteria(self):
        t = self.queue.submit_appeal("att-1", self.essay_qid, [self.cid], "x")
        other_q = next(q for q in BEGINNER_QUESTIONS if q != self.essay_qid and QUESTIONS[q].rubric_id)
        with self.assertRaises(ValueError):
            self.adjust(t, question_id=other_q)

    def test_requires_reason_reviewer_valid_score(self):
        t = self.queue.submit_appeal("att-1", self.essay_qid, [], "x")
        for kw in ({"reason": " "}, {"reviewer_id": ""}, {"new_score": 5}, {"new_score": True}):
            with self.assertRaises(ValueError, msg=str(kw)):
                self.adjust(t, **kw)
        self.assertEqual(self.queue.tickets[t.ticket_id].status, "open")


class AuditTests(unittest.TestCase):
    def test_redaction_and_permissions(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "audit.jsonl")
            log = AuditLog(path, redact_answers=True)
            log.record("model_run", answer_used="bí mật", raw_output="{}", x=1)
            with open(path, encoding="utf-8") as fh:
                line = json.loads(fh.read().strip())
            self.assertTrue(line["answer_used"]["redacted"])
            self.assertNotIn("bí mật", json.dumps(line, ensure_ascii=False))
            if os.name == "posix":
                self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)

    def test_versions_are_copied(self):
        log = AuditLog()
        e = log.record("x")
        e["versions"]["spec"] = "tampered"
        from data_analyst_ai.config import VERSIONS
        self.assertNotEqual(VERSIONS["spec"], "tampered")


if __name__ == "__main__":
    unittest.main()
