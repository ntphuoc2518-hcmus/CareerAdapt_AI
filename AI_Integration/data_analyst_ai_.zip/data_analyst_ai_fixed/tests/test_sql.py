import sqlite3
import unittest

from data_analyst_ai.fixtures import build_a_fixture, build_b_fixture
from data_analyst_ai.sql_grader import REFERENCE_SQL, SqlContract, _datasets_for, grade_sql_answer, score_sql_result
from data_analyst_ai.sql_sandbox import SqlRejected, run_readonly_query, split_statements


class SandboxTests(unittest.TestCase):
    def setUp(self):
        self.conn = build_a_fixture("base")

    def tearDown(self):
        self.conn.close()

    def test_select_works(self):
        r = run_readonly_query(self.conn, "SELECT COUNT(*) FROM orders")
        self.assertEqual(r.rows, [(10,)])

    def test_rejects_write_and_ddl(self):
        for sql in ("DELETE FROM orders", "DROP TABLE orders", "UPDATE orders SET amount=0",
                    "INSERT INTO orders VALUES (999,1,'2026-01-01',1,'x')", "CREATE TABLE t(a)",
                    "ATTACH DATABASE ':memory:' AS x", "PRAGMA table_info(orders)"):
            with self.assertRaises(SqlRejected, msg=sql):
                run_readonly_query(self.conn, sql)

    def test_rejects_multiple_statements(self):
        with self.assertRaises(SqlRejected):
            run_readonly_query(self.conn, "SELECT 1; DROP TABLE orders")

    def test_rejects_schema_and_dangerous_functions(self):
        with self.assertRaises(SqlRejected):
            run_readonly_query(self.conn, "SELECT * FROM sqlite_master")
        with self.assertRaises(SqlRejected):
            run_readonly_query(self.conn, "SELECT load_extension('x')")

    def test_runs_on_copy_so_original_unchanged(self):
        with self.assertRaises(SqlRejected):
            run_readonly_query(self.conn, "DELETE FROM orders")
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0], 10)

    def test_timeout(self):
        sql = "WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM c) SELECT COUNT(*) FROM c"
        with self.assertRaises(SqlRejected):
            run_readonly_query(self.conn, sql, timeout=0.5)

    def test_row_limit(self):
        sql = "WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM c WHERE x < 50) SELECT x FROM c"
        with self.assertRaises(SqlRejected):
            run_readonly_query(self.conn, sql, max_rows=10)

    def test_split_statements(self):
        self.assertEqual(len(split_statements("SELECT 1;\nSELECT 2;")), 2)


class GraderTests(unittest.TestCase):
    def test_reference_answers_get_full_score(self):
        for qid, ref in REFERENCE_SQL.items():
            self.assertEqual(grade_sql_answer(qid, ref).raw_score, 4.0, qid)

    def test_b_questions_have_two_datasets_except_dedupe(self):
        for qid in ("B-S1", "B-S2", "B-S3"):
            self.assertEqual([n for n, _ in _datasets_for(qid)], ["base", "alt"])
        self.assertEqual(len(_datasets_for("B-S4")), 1)

    def test_alt_dataset_gives_different_answers(self):
        # kết quả tham chiếu trên 'alt' phải khác 'base' để hard-code không qua được
        from data_analyst_ai.sql_grader import run_readonly_query as rq
        for qid in ("B-S1", "B-S2", "B-S3"):
            base = rq(build_b_fixture(), REFERENCE_SQL[qid]).rows
            alt = rq(build_b_fixture(variant="alt"), REFERENCE_SQL[qid]).rows
            self.assertNotEqual(base, alt, qid)
            self.assertTrue(alt, qid)

    def test_hardcoded_answer_fails_on_alt(self):
        from data_analyst_ai.sql_grader import run_readonly_query as rq
        base_rows = rq(build_b_fixture(), REFERENCE_SQL["B-S2"]).rows
        hardcoded = f"SELECT {base_rows[0][0]} AS repurchase_rate_30d"
        self.assertLess(grade_sql_answer("B-S2", hardcoded).raw_score, 4.0)

    def test_hardcoded_answer_fails_a_edge(self):
        self.assertLess(grade_sql_answer("A-S2", "SELECT 7").raw_score, 4.0)

    def test_syntax_error_partial_credit_or_zero(self):
        g = grade_sql_answer("A-S1", "SELEC name FROM customers")
        self.assertEqual(g.raw_score, 0.0)

    def test_destructive_sql_rejected(self):
        self.assertEqual(grade_sql_answer("A-S1", "DROP TABLE customers").raw_score, 0.0)

    def test_extra_column_scores_3(self):
        g = grade_sql_answer("A-S1", "SELECT name, city, customer_id FROM customers WHERE city = 'Hà Nội'")
        self.assertEqual(g.raw_score, 3.0, g.detail)

    def test_b_s4_needs_two_statements(self):
        self.assertEqual(grade_sql_answer("B-S4", "SELECT 1;").raw_score, 0.0)

    def test_wide_projection_is_bounded(self):
        # 8 cột thực tế, đề 5 cột: phải trả kết quả nhanh, không bùng nổ tổ hợp
        from data_analyst_ai.sql_sandbox import SqlResult
        exp = SqlResult(list("abcde"), [(1, 2, 3, 4, 5)], set())
        act = SqlResult(list("abcdefgh"), [(9, 9, 9, 9, 9, 9, 9, 9)], set())
        s, _ = score_sql_result(exp, act, SqlContract())
        self.assertLessEqual(s, 2)


if __name__ == "__main__":
    unittest.main()
