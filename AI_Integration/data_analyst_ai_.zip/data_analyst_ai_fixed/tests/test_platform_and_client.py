import subprocess
import sys
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class WindowsLikeImportTests(unittest.TestCase):
    def test_package_imports_without_resource_module(self):
        code = (
            "import sys; sys.modules['resource'] = None\n"
            "import data_analyst_ai as d\n"
            "g = d.grade_python_answer('def monthly_revenue_by_customer(df):\\n    return df\\n')\n"
            "assert g.infrastructure_error, g\n"
            "print('OK')\n")
        out = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(out.returncode, 0, out.stderr)
        self.assertIn("OK", out.stdout)


class AnthropicClientTests(unittest.TestCase):
    def test_api_errors_are_wrapped(self):
        fake = types.ModuleType("anthropic")

        class APIError(Exception):
            pass

        class Messages:
            def create(self, **kw):
                raise APIError("rate limited key=sk-secret")

        class Anthropic:
            def __init__(self, **kw):
                self.kw = kw
                self.messages = Messages()

        fake.APIError, fake.Anthropic = APIError, Anthropic
        sys.modules["anthropic"] = fake
        try:
            from data_analyst_ai.config import LLMCallError
            from data_analyst_ai.llm_layer import AnthropicClient
            client = AnthropicClient(model_id="m", api_key="k", timeout=5, max_retries=2)
            self.assertEqual(client._client.kw["timeout"], 5)
            self.assertEqual(client._client.kw["max_retries"], 2)
            with self.assertRaises(LLMCallError) as cm:
                client.complete("s", "u", temperature=0.3, max_tokens=10)
            self.assertNotIn("sk-secret", str(cm.exception))
        finally:
            del sys.modules["anthropic"]


if __name__ == "__main__":
    unittest.main()
