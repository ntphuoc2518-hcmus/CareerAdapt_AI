import os
import unittest

from data_analyst_ai.python_grader import PYTHON_TEST_CASES, grade_python_answer, run_python_sandboxed

REF_SOLUTION = '''
import pandas as pd
def monthly_revenue_by_customer(df):
    d = df.drop_duplicates().copy()
    d["order_date"] = pd.to_datetime(d["order_date"], errors="coerce")
    d["amount"] = pd.to_numeric(d["amount"], errors="coerce")
    d = d.dropna(subset=["customer_id", "order_date", "amount"])
    d["month"] = d["order_date"].dt.to_period("M").astype(str)
    return d.groupby(["customer_id", "month"], as_index=False)["amount"].sum().rename(columns={"amount": "revenue"})
'''

POSIX = hasattr(os, "killpg")


@unittest.skipUnless(POSIX, "sandbox Python cần Linux/macOS")
class PythonSandboxTests(unittest.TestCase):
    def test_correct_solution_gets_full_score(self):
        g = grade_python_answer(REF_SOLUTION)
        self.assertEqual(g.raw_score, 4.0, g.detail)

    def test_wrong_solution_scores_lower(self):
        g = grade_python_answer("def monthly_revenue_by_customer(df):\n    return df\n")
        self.assertLess(g.raw_score, 4.0)

    def test_empty_and_too_long(self):
        self.assertEqual(grade_python_answer("   ").raw_score, 0.0)
        self.assertEqual(grade_python_answer("x = 1\n" * 20000).raw_score, 0.0)

    def test_cannot_read_grader_source(self):
        code = '''
import os
def monthly_revenue_by_customer(df):
    here = %r
    return open(os.path.join(here, "python_grader.py")).read()
''' % os.path.dirname(os.path.abspath(__import__("data_analyst_ai").__file__))
        g = grade_python_answer(code)
        self.assertEqual(g.raw_score, 0.0)
        self.assertTrue(any("PermissionError" in d for d in g.detail), g.detail)

    def test_cannot_import_reference_from_repo(self):
        repo = os.path.dirname(os.path.dirname(os.path.abspath(__import__("data_analyst_ai").__file__)))
        code = f'''
import sys
sys.path.insert(0, {repo!r})
def monthly_revenue_by_customer(df):
    from data_analyst_ai.python_grader import monthly_revenue_by_customer_reference
    return monthly_revenue_by_customer_reference(df)
'''
        self.assertEqual(grade_python_answer(code).raw_score, 0.0)

    def test_raw_socket_blocked(self):
        code = '''
def monthly_revenue_by_customer(df):
    import _socket
    _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM)
    return df
'''
        g = grade_python_answer(code)
        self.assertEqual(g.raw_score, 0.0)
        self.assertTrue(any("socket" in d for d in g.detail), g.detail)

    def test_subprocess_and_fork_blocked(self):
        for body in ("import subprocess; subprocess.run(['true'])", "import os; os.system('true')", "import os; os.fork()"):
            code = f"def monthly_revenue_by_customer(df):\n    {body}\n    return df\n"
            g = grade_python_answer(code)
            self.assertEqual(g.raw_score, 0.0, body)

    def test_forged_output_is_rejected(self):
        code = '''
import os, sys, json
def monthly_revenue_by_customer(df):
    return df
sys.stdout.write("\\n@@RESULT@@" + json.dumps({"import_error": None, "cases": []}))
os._exit(0)
'''
        g = grade_python_answer(code)
        self.assertEqual(g.raw_score, 0.0)

    def test_cannot_overwrite_result_file(self):
        baseline = grade_python_answer("def monthly_revenue_by_customer(df):\n    return df\n").raw_score
        code = '''
import glob, os
def monthly_revenue_by_customer(df):
    hits = []
    for root in ("/tmp", os.environ.get("TMPDIR", "/tmp")):
        hits += glob.glob(os.path.join(root, "da_sandbox_*", "ctl", "result.json"))
    for p in hits:
        open(p, "w").write("{}")
    return df
'''
        # Không đọc/ghi được thư mục điều khiển: điểm đúng bằng baseline (không bị hỏng/giả mạo kết quả)
        self.assertEqual(grade_python_answer(code).raw_score, baseline)

    def test_timeout(self):
        res = run_python_sandboxed("while True:\n    pass\n", PYTHON_TEST_CASES, timeout=2.0)
        self.assertTrue(res.get("timeout") or res.get("crash"), res)

    def test_huge_stdout_does_not_hang_or_blow_parent(self):
        code = '''
def monthly_revenue_by_customer(df):
    import sys
    for _ in range(200000):
        sys.stderr.write("x" * 1000)
    return df
'''
        g = grade_python_answer(code)
        self.assertEqual(g.raw_score, 0.0)

    def test_memory_limit(self):
        code = '''
def monthly_revenue_by_customer(df):
    x = bytearray(4 * 1024 * 1024 * 1024)
    return df
'''
        self.assertEqual(grade_python_answer(code).raw_score, 0.0)

    def test_production_requires_container(self):
        from data_analyst_ai import python_grader as pg
        old = (pg.DEPLOY_ENV, pg.IN_ISOLATED_CONTAINER)
        try:
            pg.DEPLOY_ENV, pg.IN_ISOLATED_CONTAINER = "production", False
            g = grade_python_answer(REF_SOLUTION)
            self.assertTrue(g.infrastructure_error)
            pg.IN_ISOLATED_CONTAINER = True
            self.assertEqual(grade_python_answer(REF_SOLUTION).raw_score, 4.0)
        finally:
            pg.DEPLOY_ENV, pg.IN_ISOLATED_CONTAINER = old


if __name__ == "__main__":
    unittest.main()
