# data_analyst_ai

Lõi chấm bài và xếp lộ trình Data Analyst (đặc tả v2.0). Xem docstring ở `data_analyst_ai/__init__.py`.

## Chạy nhanh
```bash
pip install -r requirements.txt
python -m data_analyst_ai                 # self_check
python -m unittest discover -s tests -t . # 63 test (cần Linux/macOS cho test sandbox Python)
```

## Biến môi trường
| Biến | Ý nghĩa |
|---|---|
| `ANTHROPIC_API_KEY`, `GRADER_MODEL_ID` | bắt buộc khi dùng `AnthropicClient` |
| `GRADER_MODEL_VERSION` | ghi vào audit log (mặc định = model id) |
| `GRADER_TIMEOUT_SECONDS` / `GRADER_MAX_RETRIES` | timeout (60) và số lần retry (3) của SDK |
| `DA_ENV` | `dev` (mặc định) hoặc `production` |
| `DA_SANDBOX_CONTAINER` | đặt `1` khi tiến trình đã nằm trong container cô lập; bắt buộc ở production |

## Bảo mật sandbox Python (đọc kỹ trước khi mở cho học viên)
`run_python_sandboxed` có nhiều lớp bảo vệ trong tiến trình (rlimit, audit hook, whitelist đọc/ghi, kết quả qua file có
nonce) nhưng code học viên chạy **cùng tiến trình** với audit hook nên đây chỉ là *defense in depth*, không phải ranh
giới an ninh tuyệt đối. Triển khai thật cần container: không mạng, filesystem chỉ đọc (+ tmpfs nhỏ cho `/tmp`),
user không đặc quyền, `--pids-limit`, `--memory`, `--cap-drop ALL`. Xem `Dockerfile` để biết lệnh chạy mẫu.
Khuyến nghị tách: container chấm code (không mạng) và dịch vụ gọi LLM (có mạng) là hai thành phần riêng.

## Ghi chú vận hành
- `AuditLog(path, redact_answers=True)` để không lưu nguyên văn bài làm/đầu ra thô.
- `ReviewQueue` và `AuditLog` an toàn đa luồng trong một tiến trình; hàng đợi vẫn là in-memory, cần lưu bền ở lớp vận hành.
- Bài sát ngưỡng quyết định luôn thành `provisional` sau khi chấm lặp; đặt `NEAR_THRESHOLD_FORCES_REVIEW = False`
  trong `config.py` nếu không muốn.
