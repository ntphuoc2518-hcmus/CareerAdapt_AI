# Changelog

## grader-v2.1 / fixtures-v2.1

### Bảo mật
- **python_grader**: viết lại sandbox. rlimit đặt trong tiến trình con (không dùng `preexec_fn`); audit hook chặn
  `socket.*` (kể cả `_socket`), `subprocess`, `os.system/fork/exec`, `ctypes`, và chặn đọc ngoài whitelist
  (không đọc được mã nguồn/đáp án của hệ thống chấm); kết quả trả qua file trong thư mục điều khiển riêng kèm nonce
  và được kiểm tra cấu trúc (không còn tin marker `@@RESULT@@` trên stdout); stdout/stderr ghi file bị giới hạn kích
  thước; giới hạn độ dài code (`MAX_CODE_CHARS`) và số dòng kết quả.
- `DA_ENV=production` bắt buộc `DA_SANDBOX_CONTAINER=1` mới chấm Python (tránh vô tình chạy không cô lập).
- **review**: `resolve_adjustment` kiểm tra ticket thuộc đúng attempt/câu/tiêu chí, ticket phải đang mở, không sửa
  trực tiếp object đầu vào, có khóa luồng.
- **audit**: thread-safe, file 0600, tuỳ chọn `redact_answers`, `versions` được copy.

### Độ ổn định
- `import resource` được bọc: trên Windows package vẫn import được, chấm Python báo `infrastructure_error`.
- `AnthropicClient`: timeout + retry cấu hình được, mọi lỗi API thành `LLMCallError` (không lộ khóa); `essay_grader`
  bọc mọi lỗi gọi LLM; chấm bổ sung lỗi thì giữ điểm lượt đầu và thêm lý do `regrade_failed`.
- Chấm bổ sung dùng lại lượt đã có (đúng 3 lượt/câu thay vì 4-6).

### Chấm điểm
- B-S1..B-S3 chấm trên 2 dataset (`base`, `alt`) để chống hard-code.
- `_best_projection` có trần số tổ hợp; bỏ nhánh trả điểm trùng lặp.
- `limit_words` giữ nguyên xuống dòng/thụt lề.
- `NEAR_THRESHOLD_FORCES_REVIEW` (mặc định True = giữ hành vi cũ) cho phép tắt việc ép người xem khi sát ngưỡng.

### Test
- Thêm `tests/` (unittest, 63 test): sandbox Python, SQL, validate/aggregate LLM, review, attempt, audit, Windows import.
