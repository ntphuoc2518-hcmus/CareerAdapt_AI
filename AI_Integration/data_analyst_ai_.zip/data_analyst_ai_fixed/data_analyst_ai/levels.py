"""levels.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import math
from typing import Any, Iterable, Optional, Sequence

from .config import MissingDataError
from .question_bank import BEGINNER_WEIGHTS, QUESTIONS, ROLE_WEIGHTS

# --------------------------------------------------------------------------------------
# 12. Mức năng lực, điều kiện đủ, độ tin cậy (mục 1.2, 4.1-4.3)
# --------------------------------------------------------------------------------------

BEGINNER_THRESHOLDS = (30.0, 55.0, 75.0)     # L1, L2, L3
JOB_THRESHOLDS = (40.0, 60.0, 70.0)          # J1, J2, J3
BEGINNER_TARGET, JOB_TARGET = 75.0, 70.0
L2_SQL_MIN, L2_SKILL_FLOOR = 55.0, 40.0
READY_OVERALL, READY_SKILL_MIN, READY_CASE_COM_MIN = 70.0, 50.0, 60.0
CODE_AI_DISAGREEMENT = 50.0                  # chênh code vs AI (thang 100) coi là "bất đồng" -> chấm lặp


def level_index(score: float, thresholds: Sequence[float]) -> int:
    return sum(1 for t in thresholds if score >= t)


def beginner_level(score: float) -> str:
    return f"L{level_index(score, BEGINNER_THRESHOLDS)}"


def job_level(score: float) -> str:
    return f"J{level_index(score, JOB_THRESHOLDS)}"


def reliability_label(n: int) -> str:
    """n = số câu của kỹ năng: 1 -> cần xác nhận lại; 2 -> mẫu nhỏ; >=3 -> bình thường."""
    if n <= 0:
        return "chưa đủ dữ liệu"
    return {1: "cần xác nhận lại", 2: "mẫu nhỏ"}.get(n, "bình thường")


def compute_skill_scores(question_scores: dict[str, float]) -> tuple[dict[str, float], dict[str, int]]:
    """Tầng 2: trung bình cộng điểm các câu của kỹ năng (mặc định trọng số câu bằng nhau)."""
    buckets: dict[str, list[float]] = {}
    for qid, score in question_scores.items():
        q = QUESTIONS[qid]
        if q.scored and q.skill:
            buckets.setdefault(q.skill, []).append(score)
    return {s: sum(v) / len(v) for s, v in buckets.items()}, {s: len(v) for s, v in buckets.items()}


def compute_overall(skill_scores: dict[str, float], weights: dict[str, float]) -> float:
    """Tầng 3: tổng có trọng số. KHÔNG tự chuẩn hóa lại khi thiếu kỹ năng: báo lỗi cấu hình/dữ liệu."""
    if not math.isclose(sum(weights.values()), 1.0, abs_tol=1e-9):
        raise ValueError(f"Tổng trọng số kỹ năng phải bằng 1.0, hiện là {sum(weights.values())}")
    missing = set(weights) - set(skill_scores)
    if missing:
        raise ValueError(f"Thiếu điểm kỹ năng: {sorted(missing)}")
    return sum(weights[s] * skill_scores[s] for s in weights)


def assess_beginner(skill_scores: dict[str, float], counts: dict[str, int]) -> dict:
    overall = compute_overall(skill_scores, BEGINNER_WEIGHTS)
    score_level = beginner_level(overall)
    gate_ok = skill_scores["A-SQL"] >= L2_SQL_MIN and min(skill_scores.values()) >= L2_SKILL_FLOOR
    eligible = score_level
    gate_reasons: list[str] = []
    if skill_scores["A-SQL"] < L2_SQL_MIN:
        gate_reasons.append(f"A-SQL {skill_scores['A-SQL']:.1f} < {L2_SQL_MIN:.0f}")
    below = sorted(s for s, v in skill_scores.items() if v < L2_SKILL_FLOOR)
    if below:
        gate_reasons.append(f"Kỹ năng dưới {L2_SKILL_FLOOR:.0f}: {below}")
    if int(score_level[1]) >= 2 and not gate_ok:
        eligible = "L1"                      # score_level vẫn lưu theo tổng điểm; chỉ eligible bị chặn
    return {
        "overall_score": overall, "score_level": score_level, "eligible_level": eligible,
        "gate_passed": gate_ok, "gate_failures": gate_reasons,
        "gate_focus_skills": sorted(({"A-SQL"} if skill_scores["A-SQL"] < L2_SQL_MIN else set()) | set(below)),
        "recommend_job_assessment": eligible == "L3",
        "reliability": {s: reliability_label(n) for s, n in counts.items()},
    }


def assess_job(skill_scores: dict[str, float], counts: dict[str, int], role: str,
               confirmed_skills: Iterable[str] = ()) -> dict:
    if role not in ROLE_WEIGHTS:
        raise ValueError(f"Vị trí không hợp lệ: {role!r}")
    overall = compute_overall(skill_scores, ROLE_WEIGHTS[role])
    confirmed = set(confirmed_skills)
    failures: list[str] = []
    if overall < READY_OVERALL:
        failures.append(f"Điểm tổng {overall:.1f} < {READY_OVERALL:.0f}")
    for s, v in skill_scores.items():
        if counts.get(s, 0) >= 2 and v < READY_SKILL_MIN:
            failures.append(f"{s} = {v:.1f} < {READY_SKILL_MIN:.0f}")
    for s in ("B-CASE", "B-COM"):
        if skill_scores[s] < READY_CASE_COM_MIN:
            failures.append(f"{s} = {skill_scores[s]:.1f} < {READY_CASE_COM_MIN:.0f}")
    unconfirmed = sorted(s for s, n in counts.items() if n == 1 and s not in confirmed)
    if failures:
        status = "not_ready"
    elif unconfirmed:
        status = "pending_confirmation"
    else:
        status = "ready"
    return {
        "overall_score": overall, "score_level": job_level(overall), "ready_status": status,
        "ready_to_apply": status == "ready", "not_ready_reasons": failures,
        "needs_equivalent_question": unconfirmed,
        "reliability": {s: reliability_label(n) for s, n in counts.items()},
    }


def recommend_audience(selected_audience: str, a_p1: Optional[str]) -> dict:
    """Mục 4.3: tự khai chỉ để khuyến nghị tuyến làm bài, không gán năng lực."""
    if selected_audience not in ("beginner", "job_seeker"):
        raise ValueError(f"audience không hợp lệ: {selected_audience!r}")
    if selected_audience == "job_seeker" and a_p1 == "none":
        return {"recommended_audience": "beginner", "can_override": True,
                "warning": "Bạn khai chưa từng dùng Excel/SQL/Python; nên làm bài Người mới trước. "
                           "Có thể bỏ qua, lựa chọn sẽ được lưu."}
    return {"recommended_audience": selected_audience, "can_override": False, "warning": None}


def parse_goal_profile(hours_per_week: Any, weeks_available: Any, goal: Optional[str] = None) -> dict:
    """A-P2: thiếu dữ liệu -> MissingDataError để giao diện hỏi lại, không suy đoán quỹ giờ."""
    if hours_per_week is None or weeks_available is None:
        raise MissingDataError("Thiếu số giờ/tuần hoặc số tuần mục tiêu; hãy hỏi lại học viên")
    for name, v in (("hours_per_week", hours_per_week), ("weeks_available", weeks_available)):
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0:
            raise ValueError(f"{name} phải là số dương hữu hạn, nhận {v!r}")
    return {"hours_per_week": float(hours_per_week), "weeks_available": float(weeks_available), "goal": goal}
