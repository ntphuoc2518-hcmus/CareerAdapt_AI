"""data_analyst_ai.py - Lõi chấm bài và xếp lộ trình cho hệ thống đào tạo Data Analyst.

Triển khai theo "Bộ tài liệu AI chấm bài và lộ trình Data Analyst - Đặc tả v2.0".

Phạm vi (đã làm):
  * Chuẩn hóa văn bản (NFC), giới hạn 4.000 từ.
  * Rubric catalog (A1, A2, B1-B5, B-VIZ) + kiểm tra trọng số.
  * Question bank, cấu hình 8 câu theo vị trí, xáo phương án theo seed ổn định.
  * Code grader: trắc nghiệm theo option_id, SQL (sandbox SQLite chỉ đọc), Python (tiến trình con
    có giới hạn tài nguyên), kiểm tra số liệu A/B test.
  * Gọi LLM qua interface `LLMClient`; validate JSON, evidence_quote, chấm lặp, aggregate theo id.
  * Điểm câu -> kỹ năng -> tổng; mức L0-L3 / J0-J3; gate L2; ready_to_apply; reliability.
  * Module catalog (kiểm tra DAG), công thức ưu tiên, rule engine xếp lộ trình, exit test.
  * Giải thích lộ trình bằng LLM nhưng bị khóa vào output của rule engine.
  * Hàng đợi người chấm, audit log, DDL cơ sở dữ liệu tối thiểu.

Phạm vi (KHÔNG có - cần hạ tầng thật):
  * Database/API/giao diện, container cô lập cho Python học viên (xem `run_python_sandboxed` và README:
    audit hook + rlimit chỉ là lớp bảo vệ mức tiến trình, KHÔNG thay thế container không mạng. Khi
    DA_ENV=production, chấm Python từ chối chạy nếu chưa đặt DA_SANDBOX_CONTAINER=1).
  * Nội dung module thật: `SAMPLE_MODULE_CATALOG` chỉ là dữ liệu MẪU, URL = None.

Chỉ dùng thư viện chuẩn, trừ pandas (chấm B-P1) và anthropic (AnthropicClient) là tùy chọn khi chạy.
Chấm Python cần Linux/macOS (hoặc container Linux); trên Windows hệ thống báo lỗi hạ tầng thay vì chấm sai.
"""

from __future__ import annotations

from .config import *  # noqa: F401,F403
from .text_utils import *  # noqa: F401,F403
from .rubrics import *  # noqa: F401,F403
from .question_bank import *  # noqa: F401,F403
from .fixtures import *  # noqa: F401,F403
from .sql_sandbox import *  # noqa: F401,F403
from .sql_grader import *  # noqa: F401,F403
from .python_grader import *  # noqa: F401,F403
from .stats_grader import *  # noqa: F401,F403
from .llm_layer import *  # noqa: F401,F403
from .audit import *  # noqa: F401,F403
from .essay_grader import *  # noqa: F401,F403
from .levels import *  # noqa: F401,F403
from .attempt import *  # noqa: F401,F403
from .module_catalog import *  # noqa: F401,F403
from .roadmap import *  # noqa: F401,F403
from .roadmap_explainer import *  # noqa: F401,F403
from .review import *  # noqa: F401,F403
from .database import *  # noqa: F401,F403
from .testing import *  # noqa: F401,F403
from .rubrics import _c, _rubric  # noqa: F401
from .question_bank import _essay, _mcq  # noqa: F401
from .fixtures import _A_CUSTOMERS, _A_ORDERS, _A_SCHEMA, _B_DUP_EXTRA, _B_ORDERS, _B_PRODUCTS, _B_SCHEMA, _new_connection  # noqa: F401
from .sql_sandbox import _ALLOWED_ACTIONS, _BLOCKED_FUNCTIONS, _SQLITE_FUNCTION, _SQLITE_READ, _SQLITE_RECURSIVE, _SQLITE_SELECT, _normalize_cell  # noqa: F401
from .sql_grader import _SELECT_START_RE, _best_projection, _cell_key, _cells_close, _datasets_for, _grade_one_sql, _project, _rows_equal, _static_idea_recognizable  # noqa: F401
from .python_grader import _COLS, _PY_HARNESS, _normalize_py_records  # noqa: F401
from .stats_grader import _NUM_RE  # noqa: F401
from .essay_grader import _llm_run, _stable_seed  # noqa: F401
from .attempt import _answer_text, _code_grade, _decision_thresholds  # noqa: F401
from .module_catalog import _BEG, _BOTH, _LEVEL_RE, _mod  # noqa: F401
from .roadmap_explainer import _MODULE_ID_RE  # noqa: F401
