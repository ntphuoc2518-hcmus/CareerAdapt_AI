"""module_catalog.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Sequence

from .question_bank import BEGINNER_SKILLS, JOB_SKILLS, QUESTIONS

# --------------------------------------------------------------------------------------
# 14. Module catalog là nguồn sự thật duy nhất (mục 4.4)
# --------------------------------------------------------------------------------------

_LEVEL_RE = re.compile(r"^[LJ]([0-3])$")


@dataclass(frozen=True)
class Module:
    module_id: str
    title: str
    skill_code: str
    level_target: int
    prerequisites: tuple[str, ...]
    hours: float
    audience: tuple[str, ...]
    resources: tuple[dict, ...]
    exit_test: dict

    @classmethod
    def from_dict(cls, d: dict) -> "Module":
        required = {"module_id", "title", "skill_code", "level_target", "prerequisites", "hours", "audience", "resources", "exit_test"}
        missing = required - set(d)
        if missing:
            raise ValueError(f"Module thiếu trường: {sorted(missing)}")
        m = _LEVEL_RE.match(str(d["level_target"]))
        if not m:
            raise ValueError(f"{d['module_id']}: level_target không hợp lệ {d['level_target']!r}")
        return cls(d["module_id"], d["title"], d["skill_code"], int(m.group(1)), tuple(d["prerequisites"]),
                   float(d["hours"]), tuple(d["audience"]), tuple(d["resources"]), dict(d["exit_test"]))


def validate_catalog(modules: Sequence[Module]) -> dict[str, Module]:
    """Kiểm tra trước khi xuất bản: id duy nhất, kỹ năng hợp lệ, giờ > 0, tiền đề tồn tại, không chu trình,
    pass_score trong 0-100. Trả về dict module_id -> Module."""
    by_id: dict[str, Module] = {}
    valid_skills = set(BEGINNER_SKILLS) | set(JOB_SKILLS)
    for m in modules:
        if m.module_id in by_id:
            raise ValueError(f"Trùng module_id: {m.module_id}")
        by_id[m.module_id] = m
    for m in modules:
        if m.skill_code not in valid_skills:
            raise ValueError(f"{m.module_id}: skill_code không hợp lệ {m.skill_code}")
        if not (isinstance(m.hours, (int, float)) and math.isfinite(m.hours) and m.hours > 0):
            raise ValueError(f"{m.module_id}: số giờ phải dương")
        if not set(m.audience) or not set(m.audience) <= {"beginner", "job_seeker"}:
            raise ValueError(f"{m.module_id}: audience không hợp lệ")
        if not 1 <= m.level_target <= 3:
            raise ValueError(f"{m.module_id}: level_target phải trong L1-L3")
        for p in m.prerequisites:
            if p not in by_id:
                raise ValueError(f"{m.module_id}: tiền đề {p} không tồn tại")
            if p == m.module_id:
                raise ValueError(f"{m.module_id}: tự tham chiếu tiền đề")
        ps = m.exit_test.get("pass_score")
        if isinstance(ps, bool) or not isinstance(ps, (int, float)) or not 0 <= ps <= 100:
            raise ValueError(f"{m.module_id}: pass_score phải trong 0-100")
        qids = m.exit_test.get("question_ids")
        if not qids or any(q not in QUESTIONS for q in qids):
            raise ValueError(f"{m.module_id}: exit_test.question_ids không hợp lệ")
        for r in m.resources:
            if r.get("url") is not None and not str(r["url"]).startswith(("http://", "https://")):
                raise ValueError(f"{m.module_id}: URL tài nguyên không hợp lệ")
    # Phát hiện chu trình bằng Kahn
    indeg = {mid: len(m.prerequisites) for mid, m in by_id.items()}
    children: dict[str, list[str]] = {mid: [] for mid in by_id}
    for mid, m in by_id.items():
        for p in m.prerequisites:
            children[p].append(mid)
    queue = [mid for mid, d in indeg.items() if d == 0]
    seen = 0
    while queue:
        cur = queue.pop()
        seen += 1
        for ch in children[cur]:
            indeg[ch] -= 1
            if indeg[ch] == 0:
                queue.append(ch)
    if seen != len(by_id):
        cyc = sorted(mid for mid, d in indeg.items() if d > 0)
        raise ValueError(f"Đồ thị tiên quyết có chu trình liên quan: {cyc}")
    return by_id


def _mod(mid: str, title: str, skill: str, lvl: int, prereq: Sequence[str], hours: float, aud: Sequence[str],
         qids: Sequence[str], pass_score: int = 70) -> dict:
    return {"module_id": mid, "title": title, "skill_code": skill, "level_target": f"L{lvl}",
            "prerequisites": list(prereq), "hours": hours, "audience": list(aud),
            "resources": [{"type": "tutorial", "name": f"[MẪU] {title}", "url": None},
                          {"type": "practice", "name": "[MẪU] Bộ bài luyện nội bộ", "url": None}],
            "exit_test": {"question_ids": list(qids), "pass_score": pass_score}}


_BOTH, _BEG = ("beginner", "job_seeker"), ("beginner",)
# DỮ LIỆU MẪU để chạy thử thuật toán. Nội dung, giờ và tài nguyên thật do nhóm đào tạo xây và xác minh;
# URL = None nghĩa là chưa cấu hình, không phải liên kết thật (mục 4.4).
SAMPLE_MODULE_CATALOG: list[dict] = [
    _mod("STAT-01", "Khái niệm dữ liệu và thống kê mô tả", "A-STAT", 1, [], 4, _BEG, ["A-T1", "A-T2"]),
    _mod("STAT-02", "Phân phối, độ lệch, ngoại lai", "A-STAT", 2, ["STAT-01"], 5, _BEG, ["A-T4", "A-T5"]),
    _mod("STAT-03", "Tương quan, nhân quả, nhiễu", "A-STAT", 3, ["STAT-02"], 5, _BEG, ["A-T3", "A-T6"]),
    _mod("XLS-01", "Excel: bảng, hàm cơ bản", "A-XLS", 1, [], 3, _BEG, ["A-X4"]),
    _mod("XLS-02", "PivotTable và biểu đồ", "A-XLS", 2, ["XLS-01"], 4, _BEG, ["A-X1", "A-X2"]),
    _mod("XLS-03", "Trực quan hóa có chủ đích", "A-XLS", 3, ["XLS-02"], 4, _BEG, ["A-X2", "A-X3"]),
    _mod("SQL-01", "SQL: SELECT, WHERE, ORDER BY", "A-SQL", 1, [], 4, _BOTH, ["A-S1", "A-S2"]),
    _mod("SQL-02", "SQL: JOIN và GROUP BY", "A-SQL", 2, ["SQL-01"], 5, _BOTH, ["A-S3", "A-S4"]),
    _mod("SQL-03", "SQL: LEFT JOIN, NULL, truy vấn con", "A-SQL", 3, ["SQL-02"], 5, _BOTH, ["A-S4", "A-S5"]),
    _mod("SQL-04", "Window function: ROW_NUMBER, RANK, LAG", "B-SQL", 2, ["SQL-02", "SQL-03"], 6, _BOTH, ["B-S1", "B-S3"]),
    _mod("SQL-05", "SQL phân tích: cohort, trùng lặp, kỳ thiếu", "B-SQL", 3, ["SQL-04"], 6, ("job_seeker",), ["B-S2", "B-S4"]),
    _mod("READ-01", "Đọc bảng số liệu", "A-READ", 1, [], 3, _BEG, ["A-R1"]),
    _mod("READ-02", "So sánh, tỷ lệ, xu hướng", "A-READ", 2, ["READ-01"], 4, _BEG, ["A-R1", "A-R2"]),
    _mod("READ-03", "Nhận xét thận trọng, tránh kết luận nhân quả", "A-READ", 3, ["READ-02"], 4, _BEG, ["A-R2", "A-R3"]),
    _mod("PY-01", "Pandas: làm sạch và gộp dữ liệu", "B-PY", 2, [], 6, ("job_seeker",), ["B-P1"]),
    _mod("PY-02", "Kiểm định A/B và diễn giải", "B-PY", 3, ["PY-01"], 6, ("job_seeker",), ["B-P2"]),
    _mod("CASE-01", "Khung phân tích case study", "B-CASE", 2, [], 4, ("job_seeker",), ["B-C1"]),
    _mod("CASE-02", "Metric, thử nghiệm và đánh đổi", "B-CASE", 3, ["CASE-01"], 4, ("job_seeker",), ["B-C2", "B-C3"]),
    _mod("VIZ-01", "Thiết kế dashboard theo quyết định", "B-VIZ", 2, [], 4, ("job_seeker",), ["B-V1"]),
    _mod("VIZ-02", "Cảnh báo, ngưỡng và bố cục", "B-VIZ", 3, ["VIZ-01"], 4, ("job_seeker",), ["B-V1"]),
    _mod("COM-01", "Trình bày dự án theo STAR", "B-COM", 2, [], 3, ("job_seeker",), ["B-M1"]),
    _mod("COM-02", "Giải thích insight cho người không chuyên", "B-COM", 3, ["COM-01"], 3, ("job_seeker",), ["B-M2"]),
]


def load_catalog(raw_modules: Sequence[dict] = SAMPLE_MODULE_CATALOG) -> dict[str, Module]:
    return validate_catalog([Module.from_dict(d) for d in raw_modules])
