"""config.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import os
import re

# --------------------------------------------------------------------------------------
# 0. Phiên bản và cấu hình (mục 5.5: mọi thứ phải ghim phiên bản)
# --------------------------------------------------------------------------------------

VERSIONS = {
    "spec": "2.0",
    "rubric_version": "rubric-v2.0",
    "question_bank_version": "qb-v2.0",
    "grader_version": "grader-v2.1",
    "system_prompt_version": "prompt-v2.0",
    "dataset_version": "fixtures-v2.1",
    "roadmap_algorithm_version": "roadmap-v1.0",
}

MAX_WORDS = 4000
GRADING_TEMPERATURE = 0.3
MAX_FORMAT_REPAIRS = 2          # mục 2.6: sửa định dạng tối đa 2 lần
MAX_GRADING_RUNS = 3            # 1 mặc định + tối đa 2 lượt bổ sung
NEAR_THRESHOLD_MARGIN = 5       # mục 2.1: ±5 điểm
SQL_TIMEOUT_SECONDS = 5.0
SQL_MAX_ROWS = 10_000
HUMAN_REVIEW_SLA_HOURS = 48
MAX_CODE_CHARS = 50_000                # giới hạn độ dài code Python học viên gửi lên chấm
PY_SANDBOX_MEMORY_MB = 2048
PY_SANDBOX_MAX_OPEN_FILES = 256
PY_SANDBOX_MAX_FILE_BYTES = 10 * 1024 * 1024   # kích thước file tối đa tiến trình chấm được ghi (kể cả stdout/stderr)
PY_SANDBOX_MAX_RESULT_BYTES = 5 * 1024 * 1024  # kích thước tối đa của kết quả trả về cho tiến trình cha
PY_SANDBOX_MAX_RECORDS = 10_000                # số dòng tối đa mỗi test case
# Bài sát ngưỡng quyết định luôn chuyển người xem (provisional) kể cả sau khi đã chấm lặp. Đặt False nếu
# chỉ muốn chấm lặp mà không ép người xem.
NEAR_THRESHOLD_FORCES_REVIEW = True

# Môi trường chạy. Ở "production", chấm Python chỉ được chạy khi tiến trình đã nằm trong container cô lập
# (không mạng, filesystem chỉ đọc) và biến DA_SANDBOX_CONTAINER=1 được đặt.
DEPLOY_ENV = os.environ.get("DA_ENV", "dev").strip().lower()
IN_ISOLATED_CONTAINER = os.environ.get("DA_SANDBOX_CONTAINER", "").strip() == "1"

ALLOWED_CONFIDENCE = {"low", "medium", "high"}
REQUIRED_TOP = {
    "question_id", "rubric_id", "criteria", "flags",
    "strengths", "weaknesses", "feedback_to_student", "confidence",
}
FLAG_KEYS = (
    "prompt_injection", "off_topic", "empty_or_too_short",
    "copied_suspected", "evidence_fabricated",
)
P_VALUE_RE = re.compile(r"\bp[\s-]*value\b", re.IGNORECASE)


class GradingError(Exception):
    """Lỗi nghiệp vụ trong quá trình chấm (không phải lỗi dữ liệu của người học)."""


class LLMCallError(GradingError):
    """Lỗi hạ tầng khi gọi LLM (mạng, rate limit, timeout...). Không chứa khóa API hay nội dung bài làm."""


class MissingDataError(ValueError):
    """Thiếu dữ liệu đầu vào: giao diện phải hỏi lại, không được tự suy đoán (mục A-P2)."""
