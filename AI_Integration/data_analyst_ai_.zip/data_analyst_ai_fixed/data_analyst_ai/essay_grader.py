"""essay_grader.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Optional

from .config import GradingError, LLMCallError, MAX_FORMAT_REPAIRS, MAX_GRADING_RUNS, VERSIONS
from .text_utils import count_words, limit_words, sha256_json
from .rubrics import RUBRICS
from .question_bank import Question
from .llm_layer import LLMClient, ModelConfig, SYSTEM_PROMPT, aggregate_runs, build_payload, parse_llm_json, question_ai_score, score_b5_length, validate_result, zero_result
from .audit import AuditLog

# --------------------------------------------------------------------------------------
# 11. Grading orchestrator cho một câu tự luận (mục 2.1, 2.6)
# --------------------------------------------------------------------------------------

@dataclass
class EssayGrade:
    result: dict                       # kết quả đã validate/aggregate
    criterion_scores: dict[str, int]
    ai_score: float                    # thang 0-100
    runs_used: int
    truncated: bool
    answer_used: str
    review_reasons: list[str] = field(default_factory=list)
    runs: list[dict] = field(default_factory=list, repr=False)   # các lượt đã validate, dùng lại khi chấm bổ sung


def _stable_seed(*parts: Any) -> int:
    return int.from_bytes(hashlib.sha256("|".join(map(str, parts)).encode("utf-8")).digest()[:6], "big")


def _llm_run(llm: LLMClient, config: ModelConfig, question: Question, answer_used: str, *, audience: str,
             role: Optional[str], shuffle_seed: Optional[int], graded_examples: Optional[list],
             audit: AuditLog, attempt_id: str, run_index: int) -> dict:
    """Một lượt chấm: gọi model, parse, validate; sửa định dạng tối đa MAX_FORMAT_REPAIRS lần."""
    rubric = RUBRICS[question.rubric_id]
    skip = {"B5-LENGTH"} if rubric.id == "B5" else set()
    format_error: Optional[str] = None
    last_error = ""
    for attempt in range(1 + MAX_FORMAT_REPAIRS):
        payload = build_payload(question, answer_used, audience=audience, role=role, rubric_shuffle_seed=shuffle_seed,
                                graded_examples=graded_examples, format_error=format_error)
        try:
            raw = llm.complete(SYSTEM_PROMPT, payload, temperature=config.temperature, max_tokens=config.max_tokens)
        except GradingError:
            raise
        except Exception as exc:                          # lỗi mạng/SDK: không để làm sập cả attempt
            audit.record("model_error", attempt_id=attempt_id, question_id=question.question_id, run_index=run_index,
                         repair_attempt=attempt, error_type=type(exc).__name__)
            raise LLMCallError(f"{question.question_id}: lỗi gọi LLM ({type(exc).__name__})") from None
        event = {"attempt_id": attempt_id, "question_id": question.question_id, "run_index": run_index,
                 "repair_attempt": attempt, "model_provider": config.model_provider, "model_id": config.model_id,
                 "model_version": config.model_version, "temperature": config.temperature,
                 "prompt_version": VERSIONS["system_prompt_version"], "rubric_version": VERSIONS["rubric_version"],
                 "rubric_order": [c["id"] for c in json.loads(payload)["rubric"]["criteria"]],
                 "payload_hash": sha256_json(payload), "answer_used": answer_used, "raw_output": raw}
        try:
            validated = validate_result(parse_llm_json(raw), answer_used, question.question_id, rubric.id,
                                        rubric.criterion_ids, skip_quote_check_ids=skip)
        except ValueError as exc:
            last_error = str(exc)
            audit.record("model_run", validation_status="invalid", error=last_error, **event)
            format_error = last_error
            continue
        if rubric.id == "B5":
            for item in validated["criteria"]:
                if item["id"] == "B5-LENGTH":
                    item["score"] = score_b5_length(answer_used)
                    item["reason"] = f"Backend đếm {count_words(answer_used)} từ."
                    item["evidence_quote"] = ""
        audit.record("model_run", validation_status="valid", validated_output=validated, **event)
        return validated
    raise GradingError(f"{question.question_id}: JSON không qua xác thực sau {MAX_FORMAT_REPAIRS} lần sửa ({last_error})")


def grade_essay(llm: LLMClient, question: Question, answer_text: Optional[str], *, audience: str,
                role: Optional[str] = None, attempt_id: str = "attempt", extra_runs: bool = False,
                graded_examples: Optional[list] = None, audit: Optional[AuditLog] = None,
                config: Optional[ModelConfig] = None, prior_runs: Optional[list[dict]] = None) -> EssayGrade:
    """Chấm phần LLM của một câu. Mặc định MỘT lượt; ba lượt khi confidence=low hoặc `extra_runs`
    (gần ngưỡng / bất đồng code-AI do orchestrator cấp attempt quyết định). `prior_runs` là các lượt đã validate
    của CHÍNH bài làm này (lấy từ lần chấm trước): được dùng lại để chỉ gọi thêm số lượt còn thiếu cho đủ 3.

    Lỗi JSON sau khi sửa định dạng -> GradingError (đưa vào hàng đợi lỗi kỹ thuật), không bịa điểm."""
    audit = audit or AuditLog()
    config = config or ModelConfig.from_client(llm)
    answer_used, truncated = limit_words(answer_text)
    rubric = RUBRICS[question.rubric_id]
    if count_words(answer_used) == 0:
        result = zero_result(question, "Bài trống")
        if rubric.id == "B5":
            for item in result["criteria"]:
                if item["id"] == "B5-LENGTH":
                    item["score"] = 0
        scores = {c["id"]: c["score"] for c in result["criteria"]}
        return EssayGrade(result, scores, question_ai_score(rubric.id, scores), 0, False, "", [])

    runs = [copy.deepcopy(r) for r in (prior_runs or [])][:MAX_GRADING_RUNS]
    if not runs:
        runs.append(_llm_run(llm, config, question, answer_used, audience=audience, role=role, shuffle_seed=None,
                             graded_examples=graded_examples, audit=audit, attempt_id=attempt_id, run_index=1))
    if extra_runs or runs[0]["confidence"] == "low":
        while len(runs) < MAX_GRADING_RUNS:
            idx = len(runs) + 1
            seed = _stable_seed(attempt_id, question.question_id, idx)
            runs.append(_llm_run(llm, config, question, answer_used, audience=audience, role=role, shuffle_seed=seed,
                                 graded_examples=graded_examples, audit=audit, attempt_id=attempt_id, run_index=idx))
        final = aggregate_runs(runs, rubric.criterion_ids)
    else:
        final = runs[0]
    scores = {c["id"]: c["score"] for c in final["criteria"]}
    reasons = []
    if final["confidence"] == "low":
        reasons.append("confidence_low")
    if final["flags"]["evidence_fabricated"]:
        reasons.append("evidence_fabricated")
    if final.get("aggregation") and any(v >= 2 for v in final["aggregation"]["score_ranges"].values()):
        reasons.append("criterion_range_ge_2")
    return EssayGrade(final, scores, question_ai_score(rubric.id, scores), len(runs), truncated, answer_used, reasons, runs)
