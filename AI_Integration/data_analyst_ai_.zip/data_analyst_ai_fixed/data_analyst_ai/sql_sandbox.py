"""sql_sandbox.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import sqlite3
import time
from dataclasses import dataclass
from typing import Any, Optional

from .config import SQL_MAX_ROWS, SQL_TIMEOUT_SECONDS
from .text_utils import nfc
from .fixtures import unicode_nfc_collation

# --------------------------------------------------------------------------------------
# 5. SQL sandbox (mục 5.3): chỉ đọc, 1 statement, timeout, row limit - cưỡng chế ở engine
# --------------------------------------------------------------------------------------

_SQLITE_SELECT, _SQLITE_READ, _SQLITE_FUNCTION, _SQLITE_RECURSIVE = 21, 20, 31, 33
_ALLOWED_ACTIONS = {_SQLITE_SELECT, _SQLITE_READ, _SQLITE_FUNCTION, _SQLITE_RECURSIVE}
_BLOCKED_FUNCTIONS = {"load_extension", "readfile", "writefile"}


class SqlRejected(Exception):
    """Truy vấn bị từ chối vì không an toàn (DDL/DML/ATTACH/PRAGMA, nhiều statement, quá giới hạn...)."""


class SqlExecutionError(Exception):
    """Truy vấn lỗi cú pháp/runtime. `syntax` = True nếu là lỗi cú pháp."""

    def __init__(self, message: str, syntax: bool = False):
        super().__init__(message)
        self.syntax = syntax


@dataclass
class SqlResult:
    columns: list[str]
    rows: list[tuple]
    tables_read: set[str]


def _normalize_cell(value: Any) -> Any:
    if isinstance(value, str):
        return nfc(value)
    if isinstance(value, bytes):
        return value.hex()
    return value


def run_readonly_query(conn: sqlite3.Connection, sql: str, timeout: float = SQL_TIMEOUT_SECONDS,
                       max_rows: int = SQL_MAX_ROWS) -> SqlResult:
    """Chạy đúng MỘT câu SELECT/WITH trên kết nối đã nạp fixture. Trả kết quả đã chuẩn hóa NFC."""
    if not isinstance(sql, str) or not sql.strip():
        raise SqlRejected("Truy vấn trống")
    sql = nfc(sql).strip()
    tables_read: set[str] = set()

    def authorizer(action: int, arg1: Optional[str], arg2: Optional[str], db: Optional[str], src: Optional[str]) -> int:
        if action not in _ALLOWED_ACTIONS:
            return sqlite3.SQLITE_DENY
        if action == _SQLITE_FUNCTION and (arg2 or arg1 or "").lower() in _BLOCKED_FUNCTIONS:
            return sqlite3.SQLITE_DENY
        if action == _SQLITE_READ and arg1:
            if arg1.lower().startswith("sqlite_"):
                return sqlite3.SQLITE_DENY          # không đọc schema/metadata
            tables_read.add(arg1.lower())
        return sqlite3.SQLITE_OK

    deadline = time.monotonic() + timeout

    def progress() -> int:
        return 1 if time.monotonic() > deadline else 0   # 1 = ngắt truy vấn

    # Mỗi attempt dùng bản sao riêng của fixture để trạng thái không rò rỉ giữa các lần chạy.
    work = sqlite3.connect(":memory:")
    try:
        work.create_collation("UNICODE_NFC", unicode_nfc_collation)
        conn.backup(work)
        work.execute("PRAGMA query_only = ON")
        work.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, 1_000_000)
        work.setlimit(sqlite3.SQLITE_LIMIT_SQL_LENGTH, 20_000)
        work.set_authorizer(authorizer)
        work.set_progress_handler(progress, 1000)
        try:
            cursor = work.execute(sql)
        except sqlite3.ProgrammingError as exc:            # nhiều statement
            raise SqlRejected(f"Chỉ cho phép một câu lệnh: {exc}") from exc
        except sqlite3.DatabaseError as exc:
            msg = str(exc)
            if "not authorized" in msg or "authoriz" in msg or "prohibited" in msg:
                raise SqlRejected(f"Thao tác không được phép: {msg}") from exc
            if "interrupted" in msg:
                raise SqlRejected("Truy vấn vượt quá thời gian cho phép") from exc
            raise SqlExecutionError(msg, syntax=isinstance(exc, sqlite3.OperationalError)
                                    and ("syntax error" in msg.lower() or "incomplete input" in msg.lower())) from exc
        if cursor.description is None:
            raise SqlRejected("Câu lệnh không trả về tập kết quả")
        columns = [d[0] for d in cursor.description]
        try:
            raw = cursor.fetchmany(max_rows + 1)
        except sqlite3.DatabaseError as exc:
            msg = str(exc)
            if "interrupted" in msg:
                raise SqlRejected("Truy vấn vượt quá thời gian cho phép") from exc
            raise SqlExecutionError(msg) from exc
        if len(raw) > max_rows:
            raise SqlRejected(f"Kết quả vượt quá {max_rows} dòng")
        rows = [tuple(_normalize_cell(v) for v in r) for r in raw]
        return SqlResult(columns, rows, tables_read)
    finally:
        work.close()


def split_statements(script: str) -> list[str]:
    """Tách script nhiều statement (dùng cho B-S4: một câu tìm trùng + một câu giữ lại một dòng)."""
    statements, buffer = [], ""
    for line in nfc(script).splitlines(keepends=True):
        buffer += line
        if sqlite3.complete_statement(buffer):
            if buffer.strip().strip(";").strip():
                statements.append(buffer.strip())
            buffer = ""
    if buffer.strip().strip(";").strip():
        statements.append(buffer.strip())
    return statements
