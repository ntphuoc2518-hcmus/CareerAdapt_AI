"""testing.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import json
from typing import Optional

from .rubrics import validate_rubric_catalog
from .question_bank import validate_question_bank
from .sql_grader import REFERENCE_SQL, grade_sql_answer
from .module_catalog import load_catalog

# --------------------------------------------------------------------------------------
# 19. Test double cho LLM và self-check (không dùng trong vận hành)
# --------------------------------------------------------------------------------------

class MockLLM:
    """LLM giả xác định, dùng cho test/demo. Chấm mọi tiêu chí = `default_score`, trích 4 từ đầu của bài làm."""
    model_provider, model_id, model_version = "mock", "mock-grader", "0"

    def __init__(self, default_score: int = 3, confidence: str = "high", scores_by_question: Optional[dict] = None):
        self.default_score, self.confidence = default_score, confidence
        self.scores_by_question = scores_by_question or {}
        self.calls: list[dict] = []

    def complete(self, system: str, user: str, *, temperature: float, max_tokens: int) -> str:
        payload = json.loads(user)
        if "student_answer" not in payload:                       # yêu cầu giải thích lộ trình
            selected = [m["module_id"] for m in payload["selected_modules"]]
            return json.dumps({"explanation": f"Thứ tự học: {', '.join(selected)}.", "learning_goals": ["Đạt exit test lần đầu"],
                               "deferred_explanations": {m["module_id"]: "Hoãn vì quỹ giờ hoặc tiền đề." for m in payload["deferred_modules"]}},
                              ensure_ascii=False)
        self.calls.append(payload)
        answer_words = payload["student_answer"].split()
        quote = " ".join(answer_words[:4])
        base = self.scores_by_question.get(payload["question_id"], self.default_score)
        return json.dumps({
            "question_id": payload["question_id"], "rubric_id": payload["rubric_id"],
            "criteria": [{"id": c["id"], "reason": "Mock.", "evidence_quote": quote, "score": base}
                         for c in payload["rubric"]["criteria"]],
            "flags": {"prompt_injection": False, "off_topic": False, "empty_or_too_short": False,
                      "copied_suspected": False, "evidence_fabricated": False, "note": ""},
            "strengths": "Mock điểm mạnh.", "weaknesses": "Mock điểm yếu.", "feedback_to_student": "Mock phản hồi.",
            "confidence": self.confidence}, ensure_ascii=False)


def self_check() -> None:
    """Kiểm tra cấu hình tĩnh trước khi phát hành (Phụ lục A). Ném ValueError nếu có lỗi."""
    validate_rubric_catalog()
    validate_question_bank()
    load_catalog()
    for qid, ref in REFERENCE_SQL.items():
        if isinstance(ref, dict):
            if grade_sql_answer(qid, ref).raw_score != 4.0:
                raise ValueError(f"SQL tham chiếu {qid} không tự đạt 4/4")
        elif grade_sql_answer(qid, ref).raw_score != 4.0:
            raise ValueError(f"SQL tham chiếu {qid} không tự đạt 4/4")
