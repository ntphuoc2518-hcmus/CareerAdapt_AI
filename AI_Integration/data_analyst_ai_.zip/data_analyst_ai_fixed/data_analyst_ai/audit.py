"""audit.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import hashlib
import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from .config import VERSIONS

# --------------------------------------------------------------------------------------
# 10. Audit log (mục 2.6, 5.5)
# --------------------------------------------------------------------------------------

# Các trường chứa nguyên văn bài làm / đầu ra thô của model. Với redact_answers=True chỉ lưu độ dài và SHA-256.
REDACTED_FIELDS = ("answer_used", "raw_output")


def _redact(value: Any) -> dict:
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)
    return {"redacted": True, "chars": len(text), "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()}


class AuditLog:
    """Ghi sự kiện dạng JSON lines (hoặc giữ trong bộ nhớ). Mọi thay đổi điểm đều phải đi qua đây.

    * An toàn đa luồng (khóa khi ghi).
    * `redact_answers=True`: không lưu nguyên văn bài làm/đầu ra thô (phù hợp yêu cầu consent/PII).
    * File log được tạo với quyền 0600 trên hệ điều hành hỗ trợ."""

    def __init__(self, path: Optional[str | Path] = None, redact_answers: bool = False):
        self.path = Path(path) if path else None
        self.redact_answers = redact_answers
        self.events: list[dict] = []
        self._lock = threading.Lock()

    def record(self, event_type: str, **fields: Any) -> dict:
        if self.redact_answers:
            fields = {k: (_redact(v) if k in REDACTED_FIELDS else v) for k, v in fields.items()}
        event = {"ts": datetime.now(timezone.utc).isoformat(), "event": event_type,
                 "versions": dict(VERSIONS), **fields}
        line = json.dumps(event, ensure_ascii=False, default=str) + "\n"
        with self._lock:
            self.events.append(event)
            if self.path:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                fd = os.open(self.path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
                with os.fdopen(fd, "a", encoding="utf-8") as fh:
                    fh.write(line)
        return event
