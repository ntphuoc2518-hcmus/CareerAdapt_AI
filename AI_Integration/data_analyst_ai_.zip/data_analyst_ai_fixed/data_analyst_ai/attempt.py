"""attempt.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Optional

from .config import GradingError, MAX_GRADING_RUNS, NEAR_THRESHOLD_FORCES_REVIEW, NEAR_THRESHOLD_MARGIN, VERSIONS
from .text_utils import count_words
from .question_bank import BEGINNER_QUESTIONS, QUESTIONS, Question, ROLE_QUESTIONS, WORD_LIMITS, grade_mcq
from .sql_grader import CodeGrade, grade_sql_answer
from .python_grader import grade_python_answer
from .stats_grader import grade_ab_test_answer
from .llm_layer import LLMClient, ModelConfig
from .audit import AuditLog
from .essay_grader import grade_essay
from .levels import BEGINNER_THRESHOLDS, CODE_AI_DISAGREEMENT, JOB_THRESHOLDS, L2_SKILL_FLOOR, READY_CASE_COM_MIN, READY_OVERALL, READY_SKILL_MIN, assess_beginner, assess_job, compute_skill_scores

# --------------------------------------------------------------------------------------
# 13. Chấm một attempt: code + LLM, chấm lặp có chọn lọc, tổng hợp (mục 1.2, 2.1)
# --------------------------------------------------------------------------------------

@dataclass
class QuestionResult:
    question_id: str
    skill: Optional[str]
    question_score: Optional[float]              # thang 0-100; None nếu lỗi kỹ thuật
    code_score: Optional[float] = None
    ai_score: Optional[float] = None
    source: str = "code"
    confidence: str = "high"
    flags: dict = field(default_factory=dict)
    criterion_scores: dict[str, int] = field(default_factory=dict)
    review_reasons: list[str] = field(default_factory=list)
    code_detail: list[str] = field(default_factory=list)
    requirement_violations: list[str] = field(default_factory=list)
    truncated: bool = False
    unanswered: bool = False
    runs_used: int = 0
    feedback: dict = field(default_factory=dict)  # strengths/weaknesses/feedback_to_student (cần escape HTML khi hiển thị)
    essay_runs: list[dict] = field(default_factory=list, repr=False)   # các lượt LLM đã validate (dùng lại khi chấm bổ sung)


@dataclass
class AttemptResult:
    attempt_id: str
    audience: str
    role: Optional[str]
    questions: dict[str, QuestionResult]
    skill_scores: dict[str, float]
    skill_counts: dict[str, int]
    assessment: dict
    status: str                                  # "provisional" | "final"
    review_reasons: list[str]
    near_threshold_skills: list[str] = field(default_factory=list)
    versions: dict = field(default_factory=lambda: dict(VERSIONS))


def _answer_text(question: Question, answer: Any) -> str:
    """Văn bản đưa cho LLM / bộ đếm từ."""
    if answer is None:
        return ""
    if isinstance(answer, str):
        return answer
    if isinstance(answer, dict):
        if question.question_id == "B-P1":
            return f"{answer.get('explanation', '')}\n\n```python\n{answer.get('code', '')}\n```".strip()
        return "\n\n".join(f"-- {k}\n{v}" for k, v in answer.items())
    raise ValueError(f"Định dạng bài làm không hỗ trợ cho {question.question_id}: {type(answer).__name__}")


def _code_grade(question: Question, answer: Any) -> Optional[CodeGrade]:
    qid = question.question_id
    if question.kind == "mcq":
        return CodeGrade(grade_mcq(question, answer if isinstance(answer, str) else None))
    if question.kind == "sql":
        return grade_sql_answer(qid, answer)
    if question.kind == "python":
        code = answer.get("code", "") if isinstance(answer, dict) else (answer or "")
        return grade_python_answer(code)
    if question.kind == "stats":
        return grade_ab_test_answer(_answer_text(question, answer))
    return None


def near_decision_threshold(score: float, thresholds: Iterable[float], margin: float = NEAR_THRESHOLD_MARGIN) -> bool:
    return any(abs(score - t) <= margin for t in thresholds)


def _decision_thresholds(audience: str) -> dict[str, tuple[float, ...]]:
    if audience == "beginner":
        return {"overall": BEGINNER_THRESHOLDS, "skill": (L2_SKILL_FLOOR, *BEGINNER_THRESHOLDS)}
    return {"overall": JOB_THRESHOLDS + (READY_OVERALL,), "skill": (READY_SKILL_MIN, READY_CASE_COM_MIN)}


def grade_question(llm: Optional[LLMClient], question: Question, answer: Any, *, audience: str, role: Optional[str],
                   attempt_id: str, audit: AuditLog, extra_runs: bool = False,
                   cached_code: Optional[CodeGrade] = None, config: Optional[ModelConfig] = None,
                   prior_runs: Optional[list[dict]] = None) -> tuple[QuestionResult, Optional[CodeGrade]]:
    res = QuestionResult(question.question_id, question.skill, None, source="code")
    text = _answer_text(question, answer)
    res.unanswered = not text.strip() and not (question.kind == "mcq" and answer)
    code_grade = cached_code
    code100: Optional[float] = None
    if question.code_share > 0:
        if code_grade is None:
            code_grade = _code_grade(question, answer) if not res.unanswered else CodeGrade(0.0, ["Chưa nộp bài"])
        code100 = 100.0 * code_grade.raw_score / 4.0
        res.code_score, res.code_detail = code100, code_grade.detail
        if code_grade.infrastructure_error:
            res.review_reasons.append("code_checker_failed")

    ai100: Optional[float] = None
    if question.ai_share > 0:
        if llm is None:
            raise ValueError("Cần LLMClient để chấm phần tự luận")
        try:
            essay = grade_essay(llm, question, text, audience=audience, role=role, attempt_id=attempt_id,
                                extra_runs=extra_runs, audit=audit, config=config, prior_runs=prior_runs)
        except GradingError as exc:
            res.review_reasons.append("technical_error")
            res.code_detail.append(str(exc))
            res.source = "mixed" if question.code_share > 0 else "ai"
            return res, code_grade
        ai100 = essay.ai_score
        if code100 is not None and not extra_runs and abs(code100 - ai100) >= CODE_AI_DISAGREEMENT and essay.runs_used < MAX_GRADING_RUNS:
            # Bất đồng giữa code và giải thích -> chấm thêm cho đủ ba lượt (mục 2.1), dùng lại lượt đã có
            try:
                essay = grade_essay(llm, question, text, audience=audience, role=role, attempt_id=attempt_id,
                                    extra_runs=True, audit=audit, config=config, prior_runs=essay.runs)
                ai100 = essay.ai_score
            except GradingError as exc:                 # giữ kết quả lượt đầu, chuyển người xem
                res.review_reasons.append("regrade_failed")
                res.code_detail.append(str(exc))
        res.ai_score, res.criterion_scores = ai100, dict(essay.criterion_scores)
        res.confidence, res.flags = essay.result["confidence"], dict(essay.result["flags"])
        res.truncated, res.runs_used = essay.truncated, essay.runs_used
        res.essay_runs = list(essay.runs)
        res.review_reasons.extend(essay.review_reasons)
        res.feedback = {k: essay.result.get(k, "") for k in ("strengths", "weaknesses", "feedback_to_student")}
        if res.unanswered:
            res.flags["empty_or_too_short"] = True
        res.source = "mixed" if question.code_share > 0 else "ai"

    lo, hi = WORD_LIMITS.get(question.question_id, (None, None))
    if lo is not None:
        n = count_words(text)
        if not lo <= n <= hi:
            res.requirement_violations.append(f"Độ dài {n} từ ngoài khoảng {lo}-{hi}")
    code_part = question.code_share * (code100 or 0.0)
    ai_part = question.ai_share * (ai100 or 0.0)
    res.question_score = code_part + ai_part       # Tầng 1: question_score = code_share*code + ai_share*ai
    return res, code_grade


def assemble_attempt(attempt_id: str, audience: str, role: Optional[str], results: dict[str, QuestionResult],
                     confirmed_skills: Iterable[str] = ()) -> AttemptResult:
    """Gom điểm câu -> kỹ năng -> tổng -> mức/đủ điều kiện. Câu lỗi kỹ thuật không được tự gán điểm."""
    scored = {q: r.question_score for q, r in results.items() if r.question_score is not None}
    skill_scores, counts = compute_skill_scores(scored)
    reasons = sorted({f"{q}:{x}" for q, r in results.items() for x in r.review_reasons})
    try:
        assessment = assess_beginner(skill_scores, counts) if audience == "beginner" \
            else assess_job(skill_scores, counts, role or "", confirmed_skills)
    except ValueError as exc:
        assessment = {"error": str(exc), "status": "chưa đủ dữ liệu"}
        reasons.append("incomplete_scores")
    near: list[str] = []
    if "overall_score" in assessment:
        th = _decision_thresholds(audience)
        if near_decision_threshold(assessment["overall_score"], th["overall"]):
            near.append("overall")
        near += [s for s, v in skill_scores.items() if near_decision_threshold(v, th["skill"])]
        if near and NEAR_THRESHOLD_FORCES_REVIEW:
            reasons.append("near_decision_threshold")
    return AttemptResult(attempt_id, audience, role, results, skill_scores, counts, assessment,
                         "provisional" if reasons else "final", sorted(set(reasons)), near)


def grade_attempt(llm: Optional[LLMClient], audience: str, answers: dict[str, Any], *, role: Optional[str] = None,
                  attempt_id: str = "attempt", audit: Optional[AuditLog] = None,
                  confirmed_skills: Iterable[str] = (), config: Optional[ModelConfig] = None) -> AttemptResult:
    """Chấm toàn bộ bài. Một lượt LLM mỗi câu; chấm lặp chỉ cho câu tự luận thuộc kỹ năng gần ngưỡng quyết định."""
    audit = audit or AuditLog()
    if audience == "beginner":
        qids = BEGINNER_QUESTIONS
    elif audience == "job_seeker":
        if role not in ROLE_QUESTIONS:
            raise ValueError(f"Vị trí không hợp lệ: {role!r}")
        qids = ROLE_QUESTIONS[role]
    else:
        raise ValueError(f"audience không hợp lệ: {audience!r}")
    unknown = set(answers) - set(qids) - {"A-P1", "A-P2"}
    if unknown:
        raise ValueError(f"Có câu trả lời cho câu không thuộc bài: {sorted(unknown)}")

    config = config or (ModelConfig.from_client(llm) if llm is not None else None)
    results: dict[str, QuestionResult] = {}
    code_cache: dict[str, Optional[CodeGrade]] = {}
    for qid in qids:
        results[qid], code_cache[qid] = grade_question(llm, QUESTIONS[qid], answers.get(qid), audience=audience, role=role,
                                                       attempt_id=attempt_id, audit=audit, config=config)
    attempt = assemble_attempt(attempt_id, audience, role, results, confirmed_skills)

    if attempt.near_threshold_skills and llm is not None:
        regrade_all = "overall" in attempt.near_threshold_skills
        near = set(attempt.near_threshold_skills)
        for qid in qids:
            q = QUESTIONS[qid]
            if q.ai_share <= 0 or results[qid].runs_used >= MAX_GRADING_RUNS or results[qid].unanswered:
                continue
            if regrade_all or q.skill in near:
                regraded, _ = grade_question(llm, q, answers.get(qid), audience=audience, role=role,
                                             attempt_id=attempt_id, audit=audit, extra_runs=True,
                                             cached_code=code_cache[qid], config=config,
                                             prior_runs=results[qid].essay_runs)
                if regraded.question_score is None:     # chấm bổ sung lỗi: giữ điểm lượt đầu, chuyển người xem
                    results[qid].review_reasons.append("regrade_failed")
                else:
                    results[qid] = regraded
        attempt = assemble_attempt(attempt_id, audience, role, results, confirmed_skills)

    audit.record("attempt_scored", attempt_id=attempt_id, audience=audience, role=role,
                 question_scores={q: r.question_score for q, r in results.items()},
                 skill_scores=attempt.skill_scores, assessment=attempt.assessment, review_reasons=attempt.review_reasons)
    return attempt
