"""database.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import sqlite3

# --------------------------------------------------------------------------------------
# 18. Cơ sở dữ liệu tối thiểu (mục 6.3) - DDL tham chiếu, chạy được trên SQLite
# --------------------------------------------------------------------------------------

SCHEMA_SQL = """
CREATE TABLE users (user_id TEXT PRIMARY KEY, consent_status TEXT NOT NULL, created_at TEXT NOT NULL, privacy_settings TEXT);
CREATE TABLE attempts (attempt_id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(user_id), audience TEXT NOT NULL,
  role TEXT, started_at TEXT, completed_at TEXT, question_bank_version TEXT NOT NULL, dataset_version TEXT NOT NULL);
CREATE TABLE answers (attempt_id TEXT NOT NULL REFERENCES attempts(attempt_id), question_id TEXT NOT NULL,
  answer_text_or_secure_ref TEXT, option_id TEXT, truncated INTEGER NOT NULL DEFAULT 0, answer_hash TEXT NOT NULL,
  displayed_option_order TEXT, PRIMARY KEY (attempt_id, question_id));
CREATE TABLE scores (attempt_id TEXT NOT NULL, question_id TEXT NOT NULL, skill_code TEXT, question_score REAL,
  score_source TEXT, confidence TEXT, flags_json TEXT, PRIMARY KEY (attempt_id, question_id));
CREATE TABLE criterion_scores (attempt_id TEXT NOT NULL, question_id TEXT NOT NULL, rubric_id TEXT NOT NULL,
  criterion_id TEXT NOT NULL, raw_score INTEGER NOT NULL CHECK (raw_score BETWEEN 0 AND 4), reason TEXT, evidence_quote TEXT,
  reviewer_adjustment INTEGER, PRIMARY KEY (attempt_id, question_id, criterion_id));
CREATE TABLE model_runs (run_id TEXT PRIMARY KEY, attempt_id TEXT NOT NULL, question_id TEXT NOT NULL, model_id TEXT,
  model_version TEXT, prompt_version TEXT, rubric_version TEXT, temperature REAL, raw_output_ref TEXT, validation_status TEXT);
CREATE TABLE roadmaps (roadmap_id TEXT PRIMARY KEY, attempt_id TEXT NOT NULL, target REAL, hours_budget REAL,
  algorithm_version TEXT NOT NULL, ready_status TEXT);
CREATE TABLE roadmap_items (roadmap_id TEXT NOT NULL REFERENCES roadmaps(roadmap_id), order_index INTEGER NOT NULL,
  module_id TEXT NOT NULL, phase INTEGER NOT NULL, hours REAL NOT NULL, prerequisites TEXT, status TEXT, exit_test_score REAL,
  PRIMARY KEY (roadmap_id, module_id));
CREATE TABLE review_events (event_id TEXT PRIMARY KEY, attempt_id TEXT NOT NULL, reviewer_id TEXT NOT NULL,
  old_score REAL, new_score REAL, reason TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE content_versions (version_id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK (kind IN ('rubric','question','module')),
  content_hash TEXT NOT NULL, effective_at TEXT NOT NULL, created_by TEXT, change_note TEXT);
"""


def init_database(path: str = ":memory:") -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.executescript(SCHEMA_SQL)
    return conn
