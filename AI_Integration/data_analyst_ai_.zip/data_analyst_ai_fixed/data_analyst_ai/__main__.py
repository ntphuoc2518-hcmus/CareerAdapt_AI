"""Chạy: python -m data_analyst_ai"""

from __future__ import annotations

import json

from .config import VERSIONS
from .testing import self_check


if __name__ == "__main__":
    self_check()
    print("self_check OK - rubric, question bank, module catalog, SQL tham chiếu hợp lệ.")
    print(json.dumps(VERSIONS, ensure_ascii=False, indent=2))
