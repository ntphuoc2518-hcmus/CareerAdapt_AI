"""rubrics.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Optional

# --------------------------------------------------------------------------------------
# 2. Rubric catalog (mục 1A, 1B)
# --------------------------------------------------------------------------------------

@dataclass(frozen=True)
class Criterion:
    id: str
    name: str
    weight: float                      # tổng trọng số một rubric = 1.0
    levels: dict[int, str]             # mô tả mức 0-4


@dataclass(frozen=True)
class Rubric:
    id: str
    title: str
    criteria: tuple[Criterion, ...]

    @property
    def criterion_ids(self) -> list[str]:
        return [c.id for c in self.criteria]

    def weights(self) -> dict[str, float]:
        return {c.id: c.weight for c in self.criteria}


def _c(cid: str, name: str, weight: float, l4: str, l3: str, l2: str, l1: str, l0: str) -> Criterion:
    return Criterion(cid, name, weight, {4: l4, 3: l3, 2: l2, 1: l1, 0: l0})


def _rubric(rid: str, title: str, *criteria: Criterion) -> Rubric:
    return Rubric(rid, title, tuple(criteria))


RUBRICS: dict[str, Rubric] = {r.id: r for r in (
    _rubric(
        "A1", "Giải thích khái niệm (A-T5, A-T6)",
        _c("A1-ACC", "Độ chính xác khái niệm", 0.50,
           "Định nghĩa đúng; nêu điều kiện áp dụng, giới hạn hoặc điểm dễ nhầm.",
           "Định nghĩa đúng và đủ ý chính; thiếu một giới hạn nhỏ.",
           "Đúng một phần nhưng lẫn một ý quan trọng.",
           "Hiểu sai ý chính nhưng có từ khóa liên quan.",
           "Sai hoàn toàn, lạc đề hoặc bỏ trống."),
        _c("A1-EX", "Ví dụ minh họa", 0.30,
           "Ví dụ đúng, cụ thể, gắn với dữ liệu thực tế và làm rõ khái niệm.",
           "Ví dụ đúng nhưng còn chung chung.",
           "Có ví dụ nhưng liên kết với khái niệm chưa rõ.",
           "Ví dụ không phù hợp hoặc chứa lỗi đáng kể.",
           "Không có ví dụ khi câu hỏi yêu cầu."),
        _c("A1-CLR", "Diễn đạt rõ ràng", 0.20,
           "Mạch lạc; người mới có thể hiểu ngay.",
           "Rõ ý, còn một chỗ diễn đạt chưa gọn.",
           "Có thể hiểu sau khi đọc lại; tổ chức ý chưa tốt.",
           "Rời rạc, khó theo dõi.",
           "Không thể xác định được ý trả lời."),
    ),
    _rubric(
        "A2", "Đọc hiểu bảng số liệu và nhận xét (A-R1 đến A-R3)",
        _c("A2-NUM", "Đọc đúng số liệu", 0.40,
           "Trích đúng số, tính đúng mức/chiều biến động và so sánh đúng.",
           "Số liệu cốt lõi đúng; thiếu một phép so sánh nhỏ.",
           "Đúng một phần nhưng nhầm một số hoặc một phép tính quan trọng.",
           "Phần lớn số liệu hoặc phép tính sai.",
           "Không đọc được số liệu hoặc bịa số không có trong đề."),
        _c("A2-TREND", "Xu hướng và bất thường", 0.30,
           "Nêu xu hướng chính và điểm bất thường; lượng hóa khi có thể.",
           "Nêu đúng xu hướng chính, bỏ sót một tín hiệu phụ.",
           "Chỉ nêu chi tiết rời rạc, chưa kết nối xu hướng.",
           "Nhận xét không khớp bảng.",
           "Không có nhận xét có thể chấm."),
        _c("A2-CAUSAL", "Không kết luận quá đà", 0.20,
           "Phân biệt tương quan và nhân quả; nêu rõ điều chưa biết/cần kiểm chứng.",
           "Thận trọng, có nêu hạn chế nhưng chưa đầy đủ.",
           "Có kết luận hợp lý nhưng căn cứ hoặc giới hạn chưa rõ.",
           "Khẳng định nhân quả khi dữ liệu không đủ.",
           "Bịa bằng chứng hoặc số liệu không có trong đề."),
        _c("A2-CLR", "Diễn đạt", 0.10,
           "2-3 câu gọn, rõ, hướng đến quyết định.",
           "Rõ nhưng hơi dài hoặc có ý thừa.",
           "Hiểu được nhưng lủng củng.",
           "Khó hiểu.",
           "Không có câu trả lời có nghĩa."),
    ),
    _rubric(
        "B1", "Case study (B-C1 đến B-C3)",
        _c("B1-CLARIFY", "Làm rõ vấn đề", 0.15,
           "Đặt ít nhất hai câu hỏi làm rõ metric, phạm vi, thời gian hoặc phân khúc; nêu giả định.",
           "Có câu hỏi làm rõ và giả định nhưng còn thiếu một chiều quan trọng.",
           "Nhắc lại vấn đề và nêu một giả định chưa cụ thể.",
           "Hiểu chưa đúng vấn đề hoặc nhảy vào giải pháp khi thiếu dữ liệu.",
           "Không làm rõ và không xác định được bài toán."),
        _c("B1-STRUCT", "Cấu trúc tư duy", 0.25,
           "Khung phân tích có cấu trúc, đủ nhánh và hạn chế chồng lấn; có thể triển khai.",
           "Khung rõ, thiếu một nhánh quan trọng.",
           "Có ý đúng nhưng các bước rời rạc hoặc trùng lặp.",
           "Liệt kê ngẫu nhiên, thiếu logic.",
           "Không có cấu trúc phân tích."),
        _c("B1-DATA", "Dùng dữ liệu và kiểm chứng", 0.25,
           "Nêu metric, nguồn dữ liệu, cách cắt lớp và phép kiểm chứng giả thuyết.",
           "Metric phù hợp, có cách kiểm tra nhưng thiếu một chi tiết.",
           "Nhắc dữ liệu chung chung, chưa xác định cách kiểm chứng.",
           "Metric sai hoặc dữ liệu không liên quan.",
           "Không sử dụng dữ liệu hoặc bịa số liệu."),
        _c("B1-ACTION", "Insight và hành động", 0.25,
           "Kết luận có bằng chứng, đề xuất cụ thể, ưu tiên và nêu cách đo kết quả.",
           "Khuyến nghị cụ thể nhưng ưu tiên hoặc cách đo chưa rõ.",
           "Insight đúng hướng nhưng chung chung.",
           "Chỉ mô tả lại tình hình, hành động không ăn khớp.",
           "Không có kết luận hoặc đề xuất hữu ích."),
        _c("B1-COMM", "Giao tiếp", 0.10,
           "Nêu kết luận/việc cần làm trước; ngắn gọn và đúng đối tượng nghe.",
           "Rõ nhưng hơi dài.",
           "Thiếu trọng tâm hoặc dùng thuật ngữ chưa giải thích.",
           "Khó theo dõi.",
           "Không hiểu được thông điệp."),
    ),
    _rubric(
        "B2", "Chất lượng SQL nâng cao (phần AI = 30% điểm câu)",
        _c("B2-EFF", "Hiệu quả", 0.40,
           "Dùng cách tiếp cận phù hợp (CTE/window function khi cần), tránh tính toán/quét dư thừa.",
           "Cách làm hợp lý, có một điểm có thể tối ưu.",
           "Đúng nhưng có subquery hoặc phép tính lặp không cần thiết.",
           "Rất kém hiệu quả hoặc khó mở rộng.",
           "Cách làm sai bản chất hoặc không thể đánh giá."),
        _c("B2-READ", "Dễ đọc và bảo trì", 0.30,
           "Tên rõ nghĩa, định dạng nhất quán, CTE/bước trung gian dễ hiểu.",
           "Dễ đọc, chỉ có vài chỗ đặt tên/định dạng chưa tốt.",
           "Đọc được nhưng tên chung chung như a/b/t1 hoặc cấu trúc khó lần theo.",
           "Một dòng dài, khó đọc, khó bảo trì.",
           "Không thể hiểu ý định truy vấn."),
        _c("B2-EDGE", "Xử lý trường hợp biên", 0.30,
           "Xử lý đúng NULL, trùng lặp, chia cho 0/thiếu kỳ trước và tie theo yêu cầu.",
           "Xử lý các trường hợp chính, thiếu một trường hợp ít gặp.",
           "Xử lý được một phần trường hợp biên.",
           "Bỏ qua phần lớn trường hợp biên quan trọng.",
           "Không xét trường hợp biên và gây sai kết quả trọng yếu."),
    ),
    _rubric(
        "B3", "Python/Pandas và thống kê ứng dụng (phần AI = 30% điểm câu)",
        _c("B3-METHOD", "Chọn phương pháp", 0.40,
           "Chọn đúng phương pháp/kiểm định và giải thích điều kiện áp dụng.",
           "Phương pháp đúng, giải thích còn thiếu một điều kiện.",
           "Chọn đúng hướng nhưng nêu lý do mơ hồ.",
           "Chọn phương pháp không phù hợp với dữ liệu/câu hỏi.",
           "Không có phương pháp hoặc sai bản chất."),
        _c("B3-INTERPRET", "Diễn giải kết quả", 0.40,
           "Diễn giải đúng ý nghĩa p-value/khoảng tin cậy/kích thước hiệu ứng; phân biệt ý nghĩa thống kê và thực tiễn.",
           "Kết luận đúng, thiếu một chi tiết diễn giải.",
           "Nêu kết quả nhưng mơ hồ hoặc dùng thuật ngữ chưa chính xác.",
           "Hiểu sai kết quả, ví dụ xem p-value là xác suất giả thuyết đúng.",
           "Kết luận trái với kết quả đã được code xác minh."),
        _c("B3-LIMIT", "Giới hạn và rủi ro", 0.20,
           "Nêu cỡ mẫu, độ bất định, giả định và/hoặc rủi ro so sánh nhiều lần phù hợp.",
           "Nêu giới hạn chính, thiếu một điểm.",
           "Nêu một giới hạn chung chung.",
           "Giới hạn không liên quan hoặc không hiểu rủi ro.",
           "Không nêu giới hạn khi câu hỏi yêu cầu."),
    ),
    _rubric(
        "B4", "Trình bày dự án theo STAR (B-M1)",
        _c("B4-CONTEXT", "Bối cảnh và mục tiêu", 0.20,
           "Nêu vấn đề kinh doanh/người dùng, mục tiêu đo được và bối cảnh.",
           "Có bối cảnh và mục tiêu, thiếu chỉ số đo.",
           "Có bối cảnh nhưng mục tiêu mơ hồ.",
           "Bối cảnh rời rạc, không rõ vấn đề.",
           "Không có bối cảnh hoặc mục tiêu."),
        _c("B4-ROLE", "Vai trò cá nhân", 0.20,
           "Tách rõ việc cá nhân làm, công cụ dùng và quyết định cá nhân đưa ra.",
           "Vai trò rõ, thiếu một quyết định hoặc trách nhiệm.",
           "Dùng “chúng tôi” nhiều, khó xác định phần cá nhân.",
           "Vai trò gần như không rõ.",
           "Không nêu vai trò."),
        _c("B4-ACTION", "Hành động và phương pháp", 0.25,
           "Trình bày các bước phân tích có thứ tự và giải thích vì sao chọn cách đó.",
           "Có quy trình hợp lý, thiếu một giải thích.",
           "Liệt kê công cụ nhưng thiếu quy trình/lý do.",
           "Các hành động rời rạc hoặc khó tin cậy.",
           "Không có hành động cụ thể."),
        _c("B4-RESULT", "Kết quả đo được", 0.25,
           "Có số đo tác động và cách đo/đối chứng rõ.",
           "Có số liệu nhưng thiếu cách đo hoặc mốc so sánh.",
           "Chỉ có kết quả định tính hoặc số chưa được giải thích.",
           "Kết quả mơ hồ hoặc không liên quan mục tiêu.",
           "Không có kết quả."),
        _c("B4-CONSISTENCY", "Tính trung thực và nhất quán", 0.10,
           "Chi tiết nhất quán, cụ thể và có thể trả lời câu hỏi đào sâu.",
           "Nhất quán, thiếu một chi tiết nhỏ.",
           "Có một chi tiết chưa khớp, cần làm rõ.",
           "Nhiều chi tiết mâu thuẫn hoặc tuyên bố thiếu căn cứ.",
           "Bài trống/không có nội dung đánh giá được. Cờ nghi sao chép không tự động trừ điểm."),
    ),
    _rubric(
        "B5", "Giải thích insight cho người không chuyên (B-M2)",
        _c("B5-LEAD", "Kết luận trước", 0.30,
           "Câu đầu nêu kết luận và hành động đề xuất.",
           "Kết luận xuất hiện trong hai câu đầu; hành động còn chung.",
           "Có kết luận nhưng để cuối hoặc chưa nêu việc cần làm.",
           "Kết luận mơ hồ hoặc mâu thuẫn với số liệu.",
           "Không có kết luận."),
        _c("B5-LANGUAGE", "Ngôn ngữ phù hợp", 0.30,
           "Ngôn ngữ phổ thông; thuật ngữ được giải thích ngay hoặc không cần dùng.",
           "Có thuật ngữ nhưng đã giải thích gần đầy đủ.",
           "Một số thuật ngữ chưa giải thích.",
           "Dùng nhiều thuật ngữ khiến người không chuyên khó hiểu.",
           "Thông điệp không thể hiểu được."),
        _c("B5-EVIDENCE", "Bằng chứng", 0.25,
           "Dùng 1-2 con số đúng, liên quan trực tiếp kết luận và không phóng đại.",
           "Số liệu đúng nhưng thiếu ngữ cảnh hoặc một phép so sánh.",
           "Có số nhưng chưa chứng minh rõ kết luận.",
           "Số liệu sai hoặc diễn giải quá mức.",
           "Không có bằng chứng hoặc bịa số."),
        _c("B5-LENGTH", "Độ dài (backend chấm bằng code)", 0.15,
           "40-119 từ; đủ ý và gọn.",
           "120-139 từ.",
           "20-39 từ hoặc 140-160 từ.",
           "1-19 từ hoặc 161-200 từ.",
           "0 từ hoặc trên 200 từ."),
    ),
    _rubric(
        "BVIZ", "Thiết kế dashboard (B-V1)",
        _c("BVIZ-KPI", "Chỉ số gắn với quyết định", 0.30,
           "Chọn 4-6 KPI phù hợp quyết định của trưởng phòng; nêu định nghĩa hoặc mục tiêu so sánh.",
           "KPI phù hợp, thiếu định nghĩa/mục tiêu của một chỉ số.",
           "Có chỉ số liên quan nhưng danh sách thiếu ưu tiên hoặc có chỉ số không phục vụ quyết định.",
           "Chủ yếu liệt kê chỉ số chung chung, ít liên hệ quyết định.",
           "Không có KPI hữu ích."),
        _c("BVIZ-CHART", "Chọn loại biểu đồ", 0.30,
           "Chọn biểu đồ đúng loại cho KPI, xu hướng, so sánh và phân bố; nêu được lý do.",
           "Hầu hết biểu đồ phù hợp, có một lựa chọn chưa tối ưu.",
           "Có một số lựa chọn đúng nhưng nhầm loại biểu đồ ở chỉ số quan trọng.",
           "Phần lớn loại biểu đồ không phù hợp.",
           "Không chọn biểu đồ hoặc lựa chọn làm sai lệch thông tin."),
        _c("BVIZ-FILTER", "Bộ lọc và bố cục", 0.20,
           "Bộ lọc thời gian/khu vực hợp lý; thứ bậc thị giác giúp đọc từ KPI đến chi tiết.",
           "Bố cục và bộ lọc hợp lý, thiếu một thành phần.",
           "Có bộ lọc nhưng chưa gắn với tác vụ hoặc bố cục thiếu ưu tiên.",
           "Bố cục khó đọc, bộ lọc không hữu ích.",
           "Không có cấu trúc có thể dùng."),
        _c("BVIZ-DECISION", "So với mục tiêu và cảnh báo", 0.20,
           "Có so sánh với mục tiêu/ngưỡng, cảnh báo ngoại lệ và gợi ý hành động.",
           "Có mục tiêu hoặc cảnh báo phù hợp, thiếu liên kết hành động.",
           "Có so sánh chung nhưng ngưỡng/cách phản ứng chưa rõ.",
           "Cảnh báo tùy tiện hoặc không thể diễn giải.",
           "Không so sánh, không cảnh báo."),
    ),
)}


def validate_rubric_catalog(rubrics: dict[str, Rubric] = RUBRICS) -> None:
    """Checklist Phụ lục A: id duy nhất, tổng trọng số = 1, đủ mô tả mức 0-4."""
    seen: set[str] = set()
    for rid, rubric in rubrics.items():
        if rid != rubric.id:
            raise ValueError(f"Khóa rubric {rid!r} khác id {rubric.id!r}")
        if not rubric.criteria:
            raise ValueError(f"Rubric {rid} không có tiêu chí")
        total = sum(c.weight for c in rubric.criteria)
        if not math.isclose(total, 1.0, abs_tol=1e-9):
            raise ValueError(f"Rubric {rid}: tổng trọng số {total} != 1.0")
        for c in rubric.criteria:
            if c.id in seen:
                raise ValueError(f"Trùng criterion id {c.id}")
            seen.add(c.id)
            if c.weight <= 0:
                raise ValueError(f"{c.id}: trọng số phải dương")
            if set(c.levels) != {0, 1, 2, 3, 4} or not all(c.levels.values()):
                raise ValueError(f"{c.id}: thiếu mô tả mức 0-4")


def rubric_payload(rubric_id: str, shuffle_seed: Optional[int] = None) -> dict:
    """Rubric gửi cho LLM. Lượt bổ sung xáo thứ tự tiêu chí nhưng giữ nguyên id và mô tả (mục 2.1)."""
    rubric = RUBRICS[rubric_id]
    criteria = [
        {"id": c.id, "name": c.name, "weight": c.weight,
         "levels": {str(k): v for k, v in sorted(c.levels.items(), reverse=True)}}
        for c in rubric.criteria
    ]
    if shuffle_seed is not None:
        random.Random(shuffle_seed).shuffle(criteria)
    return {"id": rubric.id, "criteria": criteria}
