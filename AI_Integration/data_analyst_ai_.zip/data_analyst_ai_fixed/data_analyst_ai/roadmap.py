"""roadmap.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import heapq
from typing import Any, Iterable, Optional, Sequence

from .config import VERSIONS
from .text_utils import sha256_json
from .question_bank import BEGINNER_SKILLS, BEGINNER_WEIGHTS, JOB_SKILLS, ROLE_WEIGHTS
from .levels import BEGINNER_TARGET, BEGINNER_THRESHOLDS, JOB_TARGET, JOB_THRESHOLDS, level_index, parse_goal_profile
from .module_catalog import Module

# --------------------------------------------------------------------------------------
# 15. Công thức ưu tiên và thuật toán xếp lộ trình rule-based (mục 4.5, 4.6)
# --------------------------------------------------------------------------------------

def compute_skill_gaps(audience: str, role: Optional[str], skill_scores: dict[str, float],
                       catalog: dict[str, Module]) -> list[dict]:
    """gap = max(0, target - score); priority = gap * role_weight * prerequisite_multiplier (1.5 hoặc 1.0).
    Hệ số 1.5 chỉ lấy từ phụ thuộc đã khai báo trong catalog (module của kỹ năng s là tiền đề của module
    thuộc một kỹ năng KHÁC đang cần học)."""
    if audience == "beginner":
        target, weights, order = BEGINNER_TARGET, BEGINNER_WEIGHTS, BEGINNER_SKILLS
    elif audience == "job_seeker":
        if role not in ROLE_WEIGHTS:
            raise ValueError(f"Vị trí không hợp lệ hoặc thiếu trọng số: {role!r}")
        target, weights, order = JOB_TARGET, ROLE_WEIGHTS[role], JOB_SKILLS
    else:
        raise ValueError(f"audience không hợp lệ: {audience!r}")
    for s, v in skill_scores.items():
        if s not in weights:
            raise ValueError(f"Kỹ năng {s} không thuộc cấu hình {audience}")
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not 0 <= v <= 100:
            raise ValueError(f"Điểm kỹ năng {s} phải trong 0-100, nhận {v!r}")
    needed = {s for s, v in skill_scores.items() if v < target}
    needed_prereq_of: set[str] = set()                 # kỹ năng s là tiền đề của một kỹ năng cần học khác
    for m in catalog.values():
        if m.skill_code in needed:
            for p in m.prerequisites:
                ps = catalog[p].skill_code
                if ps != m.skill_code:
                    needed_prereq_of.add(ps)
    gaps = []
    for s, v in skill_scores.items():
        gap = max(0.0, target - v)
        mult = 1.5 if s in needed_prereq_of else 1.0
        gaps.append({"skill_code": s, "score": v, "target": target, "gap": gap, "role_weight": weights[s],
                     "prerequisite_multiplier": mult, "priority": gap * weights[s] * mult})
    # tie-break ổn định: priority giảm dần -> điểm thấp hơn trước -> thứ tự cấu hình
    gaps.sort(key=lambda g: (-g["priority"], g["score"], order.index(g["skill_code"])))
    return gaps


def evaluate_exit_test(module: Module, attempt_scores: Sequence[float]) -> dict:
    """Bước 11: sau mỗi module chạy exit test. Rớt lần 1 -> 1 chu kỳ khắc phục + thi lại một lần;
    rớt lần 2 -> instructor_review, module KHÔNG đạt và không mở khóa module phụ thuộc."""
    pass_score = module.exit_test["pass_score"]
    if len(attempt_scores) > 2:
        raise ValueError("Tối đa 2 lần thi (1 lần + 1 lần thi lại)")
    for s in attempt_scores:
        if isinstance(s, bool) or not 0 <= s <= 100:
            raise ValueError(f"Điểm exit test không hợp lệ: {s!r}")
    if not attempt_scores:
        return {"module_id": module.module_id, "status": "not_taken", "passed": False, "next_action": "take_exit_test"}
    if attempt_scores[0] >= pass_score:
        return {"module_id": module.module_id, "status": "passed", "passed": True, "next_action": None}
    if len(attempt_scores) == 1:
        return {"module_id": module.module_id, "status": "remediation_assigned", "passed": False, "next_action": "remediate_then_retest"}
    if attempt_scores[1] >= pass_score:
        return {"module_id": module.module_id, "status": "passed_after_retest", "passed": True, "next_action": None}
    return {"module_id": module.module_id, "status": "instructor_review", "passed": False, "next_action": "instructor_review"}


def passed_modules_from_results(catalog: dict[str, Module], exit_test_results: dict[str, Sequence[float]]) -> set[str]:
    """Module đạt khi exit test đạt VÀ mọi tiền đề cũng đạt (không mở khóa module phụ thuộc nếu tiền đề chưa đạt)."""
    direct = {mid for mid, scores in exit_test_results.items() if mid in catalog and evaluate_exit_test(catalog[mid], scores)["passed"]}
    changed = True
    while changed:
        changed = False
        for mid in list(direct):
            if not set(catalog[mid].prerequisites) <= direct:
                direct.discard(mid)
                changed = True
    return direct


def build_roadmap(*, audience: str, role: Optional[str], skill_scores: dict[str, float], catalog: dict[str, Module],
                  hours_per_week: Any, weeks_available: Any, passed_module_ids: Iterable[str] = (),
                  exit_test_results: Optional[dict[str, Sequence[float]]] = None,
                  focus_skills: Iterable[str] = (), skill_counts: Optional[dict[str, int]] = None,
                  ready_status: str = "not_applicable") -> dict:
    """Rule engine. LLM không được thêm/bỏ/đổi thứ tự module.

    Diễn giải các điểm spec để mở: (a) mỗi kỹ năng có gap chọn module có level_target thấp nhất lớn hơn mức
    hiện tại (mọi module chưa đạt ở đúng mức đó); mức cao hơn do lần đánh giá lại sau 2-4 tuần quyết định.
    (b) `focus_skills` (kỹ năng làm trượt gate L2) được xếp trước các kỹ năng khác để bù lỗ hổng trước.
    (c) Module không vừa quỹ giờ bị hoãn, module độc lập nhỏ hơn phía sau vẫn có thể được xếp."""
    profile = parse_goal_profile(hours_per_week, weeks_available)
    budget = profile["hours_per_week"] * profile["weeks_available"]
    gaps = compute_skill_gaps(audience, role, skill_scores, catalog)
    thresholds = BEGINNER_THRESHOLDS if audience == "beginner" else JOB_THRESHOLDS
    results = exit_test_results or {}
    for mid in results:
        if mid not in catalog:
            raise ValueError(f"exit_test_results chứa module_id không có trong catalog: {mid}")
    passed = set(passed_module_ids) | passed_modules_from_results(catalog, results)
    unknown = passed - set(catalog)
    if unknown:
        raise ValueError(f"passed_module_ids chứa module không có trong catalog: {sorted(unknown)}")
    focus = set(focus_skills)

    # Bước 4: chọn module mục tiêu cho từng kỹ năng có gap
    gap_by_skill = {g["skill_code"]: g for g in gaps}
    direct: dict[str, set[str]] = {}
    no_module: list[str] = []
    for g in gaps:
        if g["gap"] <= 0:
            continue
        s = g["skill_code"]
        cur = level_index(g["score"], thresholds)
        cands = [m for m in catalog.values() if m.skill_code == s and audience in m.audience
                 and m.level_target > cur and m.module_id not in passed]
        if not cands:
            no_module.append(s)
            continue
        lowest = min(m.level_target for m in cands)
        direct[s] = {m.module_id for m in cands if m.level_target == lowest}

    # Bước 5: thêm đệ quy mọi tiền đề chưa đạt
    selected: set[str] = set()
    prereq_added: set[str] = set()

    def add(mid: str, as_prereq: bool) -> None:
        if mid in passed:
            return
        if as_prereq:
            prereq_added.add(mid)
        if mid in selected:
            return
        selected.add(mid)
        for p in catalog[mid].prerequisites:
            add(p, True)

    for ids in direct.values():
        for mid in sorted(ids):
            add(mid, False)
    direct_ids = set().union(*direct.values()) if direct else set()

    # Ưu tiên module: của kỹ năng được đánh giá, hoặc kế thừa từ module phụ thuộc (tiền đề khác kỹ năng)
    prio: dict[str, float] = {mid: (gap_by_skill[catalog[mid].skill_code]["priority"] if catalog[mid].skill_code in gap_by_skill else 0.0)
                              for mid in selected}
    for _ in range(len(selected)):
        for mid in selected:
            for p in catalog[mid].prerequisites:
                if p in selected and catalog[p].skill_code not in gap_by_skill:
                    prio[p] = max(prio[p], prio[mid])

    def sort_key(mid: str) -> tuple:
        m = catalog[mid]
        return (0 if m.skill_code in focus else 1, -prio[mid], m.level_target, mid)

    # Bước 6-7: sắp xếp topo, trong nhóm độc lập theo ưu tiên -> mức -> module_id
    indeg = {mid: sum(1 for p in catalog[mid].prerequisites if p in selected) for mid in selected}
    children: dict[str, list[str]] = {mid: [] for mid in selected}
    for mid in selected:
        for p in catalog[mid].prerequisites:
            if p in selected:
                children[p].append(mid)
    heap = [(sort_key(mid), mid) for mid, d in indeg.items() if d == 0]
    heapq.heapify(heap)
    ordered: list[str] = []
    while heap:
        _, cur = heapq.heappop(heap)
        ordered.append(cur)
        for ch in children[cur]:
            indeg[ch] -= 1
            if indeg[ch] == 0:
                heapq.heappush(heap, (sort_key(ch), ch))
    if len(ordered) != len(selected):
        raise ValueError("Đồ thị tiên quyết có chu trình trong tập module được chọn")

    # Bước 8-10: quỹ giờ; không bao giờ xếp module khi thiếu tiền đề
    scheduled: list[str] = []
    deferred: list[tuple[str, str]] = []
    used = 0.0
    done = set(passed)
    for mid in ordered:
        m = catalog[mid]
        if not set(m.prerequisites) <= done:
            deferred.append((mid, "prerequisite"))
        elif used + m.hours <= budget + 1e-9:
            scheduled.append(mid)
            used += m.hours
            done.add(mid)
        else:
            deferred.append((mid, "budget"))

    def reason_code(mid: str) -> str:
        is_direct, is_pre = mid in direct_ids, mid in prereq_added
        return "skill_gap_and_prerequisite" if is_direct and is_pre else ("skill_gap" if is_direct else "prerequisite")

    def item(mid: str, order: int, phase: int) -> dict:
        m = catalog[mid]
        return {"module_id": mid, "title": m.title, "skill_code": m.skill_code, "order": order, "phase": phase,
                "hours": m.hours, "prerequisites": list(m.prerequisites), "reason_code": reason_code(mid),
                "exit_test": {"question_ids": list(m.exit_test["question_ids"]),
                              "pass_score": m.exit_test["pass_score"], "max_attempts": 2}}

    items = [item(mid, i + 1, 1) for i, mid in enumerate(scheduled)]
    deferred_items = [{**item(mid, len(items) + i + 1, 2), "reason": reason} for i, (mid, reason) in enumerate(deferred)]
    flags = [f"{s}:n={n}" for s, n in sorted((skill_counts or {}).items())]
    body = {
        "algorithm_version": VERSIONS["roadmap_algorithm_version"], "audience": audience, "role": role,
        "target_score": BEGINNER_TARGET if audience == "beginner" else JOB_TARGET,
        "hours_per_week": profile["hours_per_week"], "weeks_available": profile["weeks_available"],
        "hours_budget": budget, "estimated_hours": used,
        "skill_gaps": [{k: g[k] for k in ("skill_code", "score", "target", "gap", "priority")} for g in gaps if g["gap"] > 0],
        "items": items, "deferred_items": deferred_items,
        "skills_without_available_module": no_module,
        "reliability_flags": flags, "ready_status": ready_status,
        "reassess_after_weeks": [2, 4],
    }
    body["roadmap_id"] = "rm-" + sha256_json({k: v for k, v in body.items() if k != "reassess_after_weeks"})[:16]
    return body
