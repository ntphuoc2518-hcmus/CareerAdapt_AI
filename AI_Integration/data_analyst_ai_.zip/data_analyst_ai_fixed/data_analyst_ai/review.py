"""review.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import copy
import threading
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Iterable, Optional, Sequence

from .config import HUMAN_REVIEW_SLA_HOURS
from .question_bank import QUESTIONS
from .llm_layer import question_ai_score
from .audit import AuditLog
from .attempt import AttemptResult, assemble_attempt

# --------------------------------------------------------------------------------------
# 17. Người chấm, khiếu nại, điều chỉnh có lưu vết (mục 5.1)
# --------------------------------------------------------------------------------------

@dataclass
class ReviewTicket:
    ticket_id: str
    attempt_id: str
    kind: str                       # "auto_review" | "appeal"
    reasons: list[str]
    created_at: datetime
    due_at: datetime
    status: str = "open"
    question_id: Optional[str] = None
    criterion_ids: list[str] = field(default_factory=list)
    student_reason: str = ""


class ReviewQueue:
    """Hàng đợi tối giản trong bộ nhớ. 48 giờ ở đây là 48 giờ đồng hồ; lịch làm việc thật do lớp vận hành xử lý."""

    def __init__(self, audit: Optional[AuditLog] = None, sla_hours: int = HUMAN_REVIEW_SLA_HOURS):
        self.audit, self.sla_hours = audit or AuditLog(), sla_hours
        self.tickets: dict[str, ReviewTicket] = {}
        self._lock = threading.RLock()

    def enqueue_if_needed(self, attempt: AttemptResult) -> Optional[ReviewTicket]:
        if not attempt.review_reasons:
            return None
        return self._open(attempt.attempt_id, "auto_review", attempt.review_reasons)

    def submit_appeal(self, attempt_id: str, question_id: str, criterion_ids: Sequence[str], reason: str) -> ReviewTicket:
        if not reason or not reason.strip():
            raise ValueError("Khiếu nại phải ghi lý do")
        if question_id not in QUESTIONS:
            raise ValueError(f"Câu hỏi không tồn tại: {question_id}")
        t = self._open(attempt_id, "appeal", ["student_appeal"])
        t.question_id, t.criterion_ids, t.student_reason = question_id, list(criterion_ids), reason.strip()
        return t

    def _open(self, attempt_id: str, kind: str, reasons: list[str]) -> ReviewTicket:
        now = datetime.now(timezone.utc)
        with self._lock:
            tid = f"rv-{len(self.tickets) + 1:05d}"
            t = ReviewTicket(tid, attempt_id, kind, list(reasons), now, now + timedelta(hours=self.sla_hours))
            self.tickets[tid] = t
        self.audit.record("review_opened", ticket_id=tid, attempt_id=attempt_id, kind=kind, reasons=reasons, due_at=t.due_at.isoformat())
        return t

    def resolve_adjustment(self, ticket_id: str, attempt: AttemptResult, question_id: str, criterion_id: str,
                           new_score: int, reason: str, reviewer_id: str,
                           confirmed_skills: Iterable[str] = ()) -> AttemptResult:
        """Sửa điểm một tiêu chí: bắt buộc có người sửa và lý do; lưu điểm trước/sau; tính lại toàn bộ.

        * Ticket phải đang mở và thuộc đúng attempt này (và đúng câu hỏi nếu là khiếu nại).
        * Không sửa trực tiếp `attempt` truyền vào: trả về một AttemptResult mới."""
        with self._lock:
            ticket = self.tickets.get(ticket_id)
            if ticket is None:
                raise ValueError(f"Không có ticket {ticket_id}")
            if ticket.status != "open":
                raise ValueError(f"Ticket {ticket_id} đã ở trạng thái {ticket.status}, không thể sửa điểm nữa")
            if ticket.attempt_id != attempt.attempt_id:
                raise ValueError(f"Ticket {ticket_id} thuộc attempt {ticket.attempt_id}, không phải {attempt.attempt_id}")
            if ticket.kind == "appeal" and ticket.question_id != question_id:
                raise ValueError(f"Ticket khiếu nại này chỉ áp dụng cho câu {ticket.question_id}")
            if ticket.kind == "appeal" and ticket.criterion_ids and criterion_id not in ticket.criterion_ids:
                raise ValueError(f"Ticket khiếu nại này không bao gồm tiêu chí {criterion_id}")
            if not isinstance(reason, str) or not reason.strip() or not isinstance(reviewer_id, str) or not reviewer_id.strip():
                raise ValueError("Phải ghi reviewer_id và lý do khi sửa điểm")
            if question_id not in attempt.questions or criterion_id not in attempt.questions[question_id].criterion_scores:
                raise ValueError(f"Không có tiêu chí {criterion_id} ở câu {question_id}")
            if type(new_score) is not int or not 0 <= new_score <= 4:
                raise ValueError("new_score phải là số nguyên 0-4")

            working = copy.deepcopy(attempt)                      # không đụng vào object của người gọi
            res = working.questions[question_id]
            question = QUESTIONS[question_id]
            old_q, old_c = res.question_score, res.criterion_scores[criterion_id]
            res.criterion_scores[criterion_id] = new_score
            res.ai_score = question_ai_score(question.rubric_id, res.criterion_scores)
            res.question_score = question.code_share * (res.code_score or 0.0) + question.ai_share * res.ai_score
            res.review_reasons = [r for r in res.review_reasons if r != "technical_error"]
            updated = assemble_attempt(working.attempt_id, working.audience, working.role, working.questions, confirmed_skills)
            ticket.status = "resolved"
        self.audit.record("score_adjusted", ticket_id=ticket_id, attempt_id=attempt.attempt_id, question_id=question_id,
                          criterion_id=criterion_id, old_criterion_score=old_c, new_criterion_score=new_score,
                          old_question_score=old_q, new_question_score=res.question_score, reason=reason,
                          reviewer_id=reviewer_id)
        return updated
