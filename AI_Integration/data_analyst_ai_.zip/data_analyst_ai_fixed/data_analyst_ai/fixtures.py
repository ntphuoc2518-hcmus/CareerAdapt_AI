"""fixtures.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import sqlite3
import unicodedata

from .text_utils import nfc

# --------------------------------------------------------------------------------------
# 4. Fixture dữ liệu cho code grader (mục 3.1, 3.2) - cố định, có version/hash
# --------------------------------------------------------------------------------------

def unicode_nfc_collation(left: str, right: str) -> int:
    left = unicodedata.normalize("NFC", left)
    right = unicodedata.normalize("NFC", right)
    return (left > right) - (left < right)


_A_SCHEMA = """
CREATE TABLE customers (customer_id INTEGER PRIMARY KEY, name TEXT, city TEXT COLLATE UNICODE_NFC);
CREATE TABLE orders (order_id INTEGER PRIMARY KEY, customer_id INTEGER, order_date TEXT, amount INTEGER, status TEXT);
"""
_A_CUSTOMERS = [(1, "An", "Hà Nội"), (2, "Bình", "TP.HCM"), (3, "Chi", "Hà Nội"),
                (4, "Dũng", "Đà Nẵng"), (5, "Em", "TP.HCM"), (6, "Phúc", "Hà Nội")]
_A_ORDERS = [
    (101, 1, "2026-01-05", 500000, "completed"), (102, 1, "2026-02-10", 300000, "completed"),
    (103, 2, "2026-01-15", 1200000, "completed"), (104, 2, "2026-03-01", 200000, "cancelled"),
    (105, 3, "2026-02-20", 800000, "completed"), (106, 4, "2026-03-05", 150000, "completed"),
    (107, 5, "2026-03-10", 950000, "completed"), (108, 5, "2026-03-12", 400000, "cancelled"),
    (109, 3, "2026-03-15", 650000, "completed"), (110, 2, "2026-03-20", 700000, "completed"),
]

_B_SCHEMA = """
CREATE TABLE products (product_id INTEGER PRIMARY KEY, product_name TEXT, category TEXT);
CREATE TABLE orders (order_id INTEGER, customer_id INTEGER, product_id INTEGER, order_date TEXT,
                     quantity INTEGER, unit_price INTEGER, status TEXT);
"""
_B_PRODUCTS = [(1, "Alpha", "Laptop"), (2, "Beta", "Laptop"), (3, "Gamma", "Laptop"), (4, "Delta", "Laptop"),
               (5, "Epsilon", "Laptop"), (6, "Dây sạc", "Phụ kiện"), (7, "Chuột", "Phụ kiện"),
               (8, "Túi", "Phụ kiện"), (9, "Màn hình 27", "Màn hình")]
# (order_id, customer_id, product_id, order_date, quantity, unit_price, status)
# Cố ý có: đồng hạng (Alpha=Beta, Dây sạc=Chuột), khách chỉ có đơn hủy (6), tháng thiếu (2026-04),
# mua lại đúng ngày thứ 30 (khách 5) và ngày thứ 31 (khách 4).
_B_ORDERS = [
    (1, 1, 1, "2026-01-05", 2, 1000, "completed"), (2, 2, 2, "2026-01-20", 1, 2000, "completed"),
    (3, 3, 3, "2026-02-03", 1, 1500, "completed"), (4, 4, 4, "2026-02-10", 1, 1200, "completed"),
    (5, 5, 5, "2026-02-15", 1, 100, "completed"), (6, 1, 6, "2026-02-20", 10, 50, "completed"),
    (7, 2, 7, "2026-02-25", 5, 100, "completed"), (8, 3, 8, "2026-02-28", 2, 100, "completed"),
    (9, 5, 9, "2026-03-17", 3, 300, "completed"), (10, 4, 8, "2026-03-13", 1, 100, "completed"),
    (11, 6, 4, "2026-03-05", 1, 1200, "cancelled"), (12, 1, 5, "2026-05-10", 1, 100, "completed"),
    (13, 5, 5, "2026-05-12", 1, 5000, "cancelled"),
]
# Bản có order_id trùng cho B-S4: id 3 trùng khác ngày; id 7 trùng cùng ngày (phải phá hòa bằng rowid).
_B_DUP_EXTRA = [
    (3, 3, 3, "2026-02-01", 1, 1500, "completed"),
    (7, 2, 7, "2026-02-25", 4, 100, "completed"),
]

# Bộ dữ liệu thứ hai cho B-S1..B-S3 (chống hard-code kết quả): đồng hạng khác chỗ, mua lại đúng ngày 30 (qua tháng 2 ngắn),
# khách có hai đơn liên tiếp, tháng thiếu (2026-04, 2026-05) và danh mục có hai sản phẩm đồng hạng.
_B_PRODUCTS_ALT = _B_PRODUCTS + [(10, "Màn hình 24", "Màn hình"), (11, "Bàn phím", "Phụ kiện")]
_B_ORDERS_ALT = [
    (1, 1, 1, "2026-02-01", 3, 900, "completed"), (2, 2, 2, "2026-02-04", 2, 1000, "completed"),
    (3, 3, 3, "2026-02-09", 1, 2000, "completed"), (4, 4, 4, "2026-03-02", 1, 500, "completed"),
    (5, 5, 5, "2026-03-15", 4, 300, "completed"), (6, 1, 1, "2026-03-03", 1, 900, "completed"),
    (7, 2, 10, "2026-03-10", 2, 800, "completed"), (8, 6, 11, "2026-02-20", 6, 100, "completed"),
    (9, 6, 7, "2026-02-21", 1, 150, "completed"), (10, 7, 6, "2026-04-01", 1, 70, "cancelled"),
    (11, 3, 8, "2026-06-01", 5, 20, "completed"), (12, 4, 9, "2026-02-12", 1, 3000, "completed"),
    (13, 8, 9, "2026-02-13", 1, 3000, "completed"),
]


def _new_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.create_collation("UNICODE_NFC", unicode_nfc_collation)
    return conn


def build_a_fixture(variant: str = "base") -> sqlite3.Connection:
    """Benchmark SQL cho nhóm Người mới. `edge` thêm NFD, NULL và khách không có đơn (mục 3.1)."""
    conn = _new_connection()
    conn.executescript(_A_SCHEMA)
    conn.executemany("INSERT INTO customers VALUES (?,?,?)",
                     [(i, nfc(n), nfc(c)) for i, n, c in _A_CUSTOMERS])
    conn.executemany("INSERT INTO orders VALUES (?,?,?,?,?)", _A_ORDERS)
    if variant == "edge":
        # Thành phố ở dạng NFD cố ý KHÔNG chuẩn hóa khi nạp: cột COLLATE UNICODE_NFC phải gộp đúng.
        conn.execute("INSERT INTO customers VALUES (7,'Giang',?)", (unicodedata.normalize("NFD", "Hà Nội"),))
        conn.execute("INSERT INTO customers VALUES (8,'Hạnh',NULL)")
        conn.execute("INSERT INTO orders VALUES (111,7,'2026-03-22',100000,'completed')")
        conn.execute("INSERT INTO orders VALUES (112,NULL,'2026-03-23',50000,'completed')")
    elif variant != "base":
        raise ValueError(f"variant không hợp lệ: {variant}")
    conn.commit()
    return conn


def build_b_fixture(with_duplicates: bool = False, variant: str = "base") -> sqlite3.Connection:
    """Benchmark SQL cho nhóm Người đi làm. `variant="alt"` là bộ dữ liệu thứ hai (không dùng cùng `with_duplicates`)."""
    if variant not in ("base", "alt"):
        raise ValueError(f"variant không hợp lệ: {variant}")
    if variant == "alt" and with_duplicates:
        raise ValueError("variant 'alt' không hỗ trợ with_duplicates")
    conn = _new_connection()
    conn.executescript(_B_SCHEMA)
    products, orders = (_B_PRODUCTS_ALT, _B_ORDERS_ALT) if variant == "alt" else (_B_PRODUCTS, _B_ORDERS)
    conn.executemany("INSERT INTO products VALUES (?,?,?)", [(i, nfc(n), nfc(c)) for i, n, c in products])
    conn.executemany("INSERT INTO orders VALUES (?,?,?,?,?,?,?)", orders)
    if with_duplicates:
        conn.executemany("INSERT INTO orders VALUES (?,?,?,?,?,?,?)", _B_DUP_EXTRA)
    conn.commit()
    return conn
