"""text_utils.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from typing import Any, Optional

from .config import MAX_WORDS, P_VALUE_RE

# --------------------------------------------------------------------------------------
# 1. Chuẩn hóa văn bản (mục 5.4)
# --------------------------------------------------------------------------------------

def nfc(text: Optional[str]) -> str:
    return unicodedata.normalize("NFC", text or "")


def norm(text: Optional[str]) -> str:
    """NFC + gộp khoảng trắng + casefold để so khớp tiếng Việt nhất quán."""
    return re.sub(r"\s+", " ", nfc(text)).strip().casefold()


def count_words(text: Optional[str]) -> int:
    return len(re.findall(r"\S+", nfc(text)))


def limit_words(answer: Optional[str], max_words: int = MAX_WORDS) -> tuple[str, bool]:
    """Trả về (văn bản đã NFC và giới hạn từ, có_bị_cắt). Đếm theo token tách bởi khoảng trắng.
    Phần giữ lại là đoạn đầu NGUYÊN VĂN (giữ xuống dòng và thụt lề, quan trọng với code)."""
    answer = nfc(answer)
    last_end = 0
    for count, match in enumerate(re.finditer(r"\S+", answer)):
        if count == max_words:
            return answer[:last_end], True
        last_end = match.end()
    return answer, False


def detect_p_value_term(text: str) -> bool:
    """Chỉ là tín hiệu; rubric B5-LANGUAGE quyết định thuật ngữ có được giải thích hay không."""
    return bool(P_VALUE_RE.search(nfc(text)))


def sha256_json(obj: Any) -> str:
    raw = json.dumps(obj, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
