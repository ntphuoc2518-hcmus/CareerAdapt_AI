"""python_grader.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import json
import os
import secrets
import signal
import subprocess
import sys
import tempfile
import warnings
from pathlib import Path
from typing import Any, Optional

try:                                    # `resource` chỉ có trên Unix; thiếu thì chấm Python báo lỗi hạ tầng
    import resource
except ImportError:                     # pragma: no cover - Windows
    resource = None                     # type: ignore[assignment]

from .config import DEPLOY_ENV, IN_ISOLATED_CONTAINER, MAX_CODE_CHARS, PY_SANDBOX_MAX_FILE_BYTES, \
    PY_SANDBOX_MAX_OPEN_FILES, PY_SANDBOX_MAX_RECORDS, PY_SANDBOX_MAX_RESULT_BYTES, PY_SANDBOX_MEMORY_MB
from .text_utils import nfc
from .sql_grader import CodeGrade

# --------------------------------------------------------------------------------------
# 7. Chấm Python (B-P1): tiến trình con có giới hạn - KHÔNG thay thế container cô lập
# --------------------------------------------------------------------------------------

def monthly_revenue_by_customer_reference(df):
    """Bản tham chiếu B-P1 (mục 3.2)."""
    import pandas as pd
    required = {"customer_id", "order_date", "amount"}
    missing_cols = required - set(df.columns)
    if missing_cols:
        raise ValueError(f"Thiếu cột bắt buộc: {sorted(missing_cols)}")
    before = len(df)
    clean = df.drop_duplicates().copy()
    rows_after_exact_dedup = len(clean)
    clean["order_date"] = pd.to_datetime(clean["order_date"], errors="coerce")
    clean["amount"] = pd.to_numeric(clean["amount"], errors="coerce")
    invalid_date_rows = int(clean["order_date"].isna().sum())
    invalid_amount_rows = int(clean["amount"].isna().sum())
    clean = clean.dropna(subset=["customer_id", "order_date", "amount"])
    clean["month"] = clean["order_date"].dt.to_period("M").astype(str)
    result = (clean.groupby(["customer_id", "month"], as_index=False)["amount"].sum()
              .rename(columns={"amount": "revenue"}))
    audit = {"input_rows": before, "rows_after_exact_dedup": rows_after_exact_dedup,
             "invalid_date_rows": invalid_date_rows, "invalid_or_missing_amount_rows": invalid_amount_rows,
             "rows_used": int(len(clean))}
    return result, audit


_COLS = ["customer_id", "order_date", "amount"]
PYTHON_TEST_CASES: list[dict] = [
    {"name": "normal", "rows": [[1, "2026-01-05", 100], [1, "2026-01-20", 50], [2, "2026-02-01", 70], [1, "2026-02-03", 30]]},
    {"name": "exact_duplicates", "rows": [[1, "2026-01-05", 100], [1, "2026-01-05", 100], [2, "2026-01-07", 40]]},
    {"name": "missing_amount_or_date", "rows": [[1, "2026-01-05", None], [1, "2026-01-06", 25], [2, None, 10], [2, "2026-03-02", 5]]},
    {"name": "empty", "rows": []},
    {"name": "zero_amount", "rows": [[1, "2026-01-05", 0], [1, "2026-01-09", 10]]},
    {"name": "bad_date_format", "rows": [[1, "không-phải-ngày", 10], [1, "2026-04-01", 20], [3, "2026/04/15", 5]]},
]

_PY_HARNESS = r"""
import json, os, sys


def _main():
    ctl = sys.argv[1]
    with open(os.path.join(ctl, "spec.json"), encoding="utf-8") as fh:
        spec = json.load(fh)
    with open(spec["code_path"], encoding="utf-8") as fh:
        code_text = fh.read()
    sys.dont_write_bytecode = True

    # 1) Giới hạn tài nguyên đặt NGAY trong tiến trình con (soft = hard nên không nâng lại được).
    import resource
    lim = spec["limits"]
    for name, value in (("RLIMIT_CPU", lim["cpu_seconds"]), ("RLIMIT_AS", lim["memory_bytes"]),
                        ("RLIMIT_FSIZE", lim["file_bytes"]), ("RLIMIT_NOFILE", lim["open_files"]),
                        ("RLIMIT_CORE", 0)):
        res = getattr(resource, name, None)
        if res is not None:
            resource.setrlimit(res, (value, value))

    # 2) Nạp mọi thứ harness cần TRƯỚC khi bật audit hook.
    import warnings
    warnings.simplefilter("ignore")
    import pandas as pd
    import numpy  # noqa: F401
    result_fh = open(os.path.join(ctl, "result.json"), "w", encoding="utf-8")
    sys.stdout = open(os.devnull, "w", encoding="utf-8")       # print() của học viên không đi đâu cả

    work = os.path.realpath(spec["work_dir"])
    deny = tuple(os.path.realpath(p) for p in spec["deny_paths"])
    read_roots = {os.path.realpath(p) for p in (sys.prefix, sys.base_prefix, sys.exec_prefix, sys.base_exec_prefix)}
    read_roots |= {os.path.realpath(p) for p in sys.path if p}
    read_roots |= {"/lib", "/lib64", "/usr/lib", "/usr/lib64", "/usr/share", "/etc/localtime", "/etc/ld.so.cache",
                   "/proc/self", "/proc/meminfo", "/proc/cpuinfo", "/sys/devices/system/cpu", "/sys/fs/cgroup",
                   "/dev/urandom", "/dev/random", "/dev/null"}
    read_roots = tuple(sorted(read_roots))
    proc_secret = ("/proc/self/environ", "/proc/self/mem", "/proc/self/cmdline", "/proc/self/fd", "/proc/self/cwd",
                   "/proc/self/root", "/proc/self/exe")
    write_bits = os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND

    block_exact = {"os.system", "os.fork", "os.forkpty", "os.kill", "os.killpg", "os.chdir", "os.chroot",
                   "os.putenv", "os.unsetenv", "sys.settrace", "sys.setprofile", "os.setuid", "os.setgid"}
    block_prefix = ("socket.", "subprocess.", "_posixsubprocess.", "ctypes.", "os.exec", "os.spawn", "os.posix_spawn",
                    "multiprocessing.", "pty.", "urllib.", "http.client.", "ftplib.", "smtplib.", "telnetlib.",
                    "webbrowser.", "resource.", "mmap.", "_winapi.", "msvcrt.")
    path_events = {"os.remove", "os.rmdir", "os.mkdir", "os.rename", "os.chmod", "os.chown", "os.truncate",
                   "os.symlink", "os.link", "os.utime", "shutil.copyfile", "shutil.copytree", "shutil.move",
                   "shutil.rmtree", "shutil.copymode", "shutil.copystat", "shutil.copy"}

    def under(path, roots):
        return any(path == r or path.startswith(r.rstrip(os.sep) + os.sep) for r in roots)

    def norm(path):
        if isinstance(path, bytes):
            path = os.fsdecode(path)
        path = os.fspath(path)
        if not os.path.isabs(path):
            path = os.path.join(work, path)
        return os.path.realpath(path)

    def deny_read(path):
        return under(path, deny) or any(path == q or path.startswith(q + "/") for q in proc_secret)

    def hook(event, args):
        if event in block_exact or event.startswith(block_prefix):
            raise PermissionError("sandbox: thao tác bị chặn (" + event + ")")
        if event == "open":
            path, mode, flags = args
            if isinstance(path, int):
                return
            p = norm(path)
            writing = (isinstance(mode, str) and any(c in mode for c in "wax+")) or \
                      (isinstance(flags, int) and bool(flags & write_bits))
            if deny_read(p):
                raise PermissionError("sandbox: không được truy cập đường dẫn này")
            if writing:
                if not under(p, (work,)):
                    raise PermissionError("sandbox: chỉ được ghi trong thư mục làm việc")
            elif not under(p, (work,) + read_roots):
                raise PermissionError("sandbox: không được đọc ngoài thư mục cho phép")
        elif event in ("os.listdir", "os.scandir"):
            path = args[0]
            if path is None or isinstance(path, int):
                return
            p = norm(path)
            if deny_read(p) or not under(p, (work,) + read_roots):
                raise PermissionError("sandbox: không được liệt kê thư mục này")
        elif event in path_events:
            for a in args:
                if isinstance(a, (str, bytes, os.PathLike)):
                    if not under(norm(a), (work,)):
                        raise PermissionError("sandbox: chỉ được thao tác file trong thư mục làm việc")

    sys.addaudithook(hook)

    # 3) Chạy code học viên.
    ns = {"__name__": "student_module"}
    out = {"nonce": spec["nonce"], "import_error": None, "cases": []}
    fn = None
    try:
        exec(compile(code_text, "student_code", "exec"), ns)
        fn = ns.get("monthly_revenue_by_customer")
        if not callable(fn):
            raise RuntimeError("Không tìm thấy hàm monthly_revenue_by_customer(df)")
    except BaseException as exc:
        out["import_error"] = type(exc).__name__ + ": " + str(exc)[:300]
        fn = None
    max_records = lim["max_records"]
    for case in spec["cases"]:
        entry = {"name": case["name"], "error": None, "records": None, "columns": None}
        if fn is not None:
            try:
                df = pd.DataFrame(case["rows"], columns=spec["columns"])
                res = fn(df)
                if isinstance(res, tuple):
                    res = res[0]
                res = pd.DataFrame(res).reset_index(drop=True)
                if len(res) > max_records:
                    raise RuntimeError("Kết quả quá nhiều dòng")
                entry["records"] = json.loads(res.to_json(orient="records", date_format="iso"))
                entry["columns"] = [str(c) for c in res.columns]
            except BaseException as exc:
                entry["error"] = type(exc).__name__ + ": " + str(exc)[:300]
        out["cases"].append(entry)
    result_fh.write(json.dumps(out, ensure_ascii=False))
    result_fh.flush()
    result_fh.close()
    os._exit(0)


_main()
"""


def _sandbox_unsupported_reason() -> Optional[str]:
    if resource is None or not hasattr(os, "killpg"):
        return "Chấm Python cần Linux/macOS (hoặc container Linux); hệ điều hành hiện tại không hỗ trợ giới hạn tài nguyên"
    if DEPLOY_ENV == "production" and not IN_ISOLATED_CONTAINER:
        return "Môi trường production yêu cầu chạy trong container cô lập (đặt DA_SANDBOX_CONTAINER=1 khi đã cô lập)"
    return None


def _read_tail(path: Path, limit: int = 500) -> str:
    try:
        size = path.stat().st_size
        with path.open("rb") as fh:
            fh.seek(max(0, size - limit))
            return fh.read(limit).decode("utf-8", errors="replace")
    except OSError:
        return ""


def _valid_sandbox_result(data: Any, cases: list[dict], nonce: str) -> bool:
    """Kiểm tra cấu trúc kết quả do tiến trình con trả về (không tin dữ liệu từ phía học viên)."""
    if not isinstance(data, dict) or not isinstance(data.get("nonce"), str):
        return False
    if not secrets.compare_digest(data["nonce"].encode("utf-8"), nonce.encode("utf-8")):
        return False
    if data.get("import_error") is not None and not isinstance(data["import_error"], str):
        return False
    got = data.get("cases")
    if not isinstance(got, list) or len(got) != len(cases):
        return False
    for case, entry in zip(cases, got):
        if not isinstance(entry, dict) or entry.get("name") != case["name"]:
            return False
        if entry.get("error") is not None and not isinstance(entry["error"], str):
            return False
        recs = entry.get("records")
        if recs is not None and (not isinstance(recs, list) or not all(isinstance(r, dict) for r in recs)):
            return False
    return True


def run_python_sandboxed(code: str, cases: list[dict], timeout: float = 20.0,
                         memory_mb: int = PY_SANDBOX_MEMORY_MB) -> dict:
    """Chạy code học viên trong tiến trình con riêng.

    Lớp bảo vệ trong tiến trình (defense in depth): môi trường sạch, thư mục làm việc tạm, rlimit đặt trong
    chính tiến trình con, audit hook chặn socket/subprocess/ctypes/fork và chặn đọc ngoài whitelist
    (kể cả mã nguồn của hệ thống chấm), kết quả trả qua file có nonce thay vì stdout, stdout/stderr ghi file có
    giới hạn kích thước, kill cả process group khi timeout.

    LƯU Ý: audit hook chạy trong cùng tiến trình với code học viên nên KHÔNG phải ranh giới an ninh tuyệt đối.
    Triển khai thật PHẢI chạy trong container không mạng, filesystem chỉ đọc, user không đặc quyền
    (xem README). Khi DA_ENV=production, hàm từ chối chạy nếu chưa khai báo DA_SANDBOX_CONTAINER=1."""
    reason = _sandbox_unsupported_reason()
    if reason:
        return {"unsupported": reason}
    with tempfile.TemporaryDirectory(prefix="da_sandbox_") as tmp:
        root = Path(os.path.realpath(tmp))
        work, ctl = root / "work", root / "ctl"
        work.mkdir()
        ctl.mkdir()
        os.chmod(ctl, 0o700)
        nonce = secrets.token_hex(16)
        code_path = work / "student_code.py"
        code_path.write_text(nfc(code), encoding="utf-8")
        (ctl / "harness.py").write_text(_PY_HARNESS, encoding="utf-8")
        spec = {
            "code_path": str(code_path), "work_dir": str(work), "ctl_dir": str(ctl), "nonce": nonce,
            "cases": cases, "columns": _COLS,
            "deny_paths": [str(ctl), str(Path(__file__).resolve().parent)],
            "limits": {"cpu_seconds": int(timeout) + 1, "memory_bytes": int(memory_mb) * 1024 * 1024,
                       "file_bytes": PY_SANDBOX_MAX_FILE_BYTES, "open_files": PY_SANDBOX_MAX_OPEN_FILES,
                       "max_records": PY_SANDBOX_MAX_RECORDS},
        }
        (ctl / "spec.json").write_text(json.dumps(spec, ensure_ascii=False), encoding="utf-8")
        env = {"PATH": "/usr/bin:/bin", "PYTHONHASHSEED": "0", "HOME": str(work), "TMPDIR": str(work),
               "PYTHONDONTWRITEBYTECODE": "1", "PYTHONIOENCODING": "utf-8", "OPENBLAS_NUM_THREADS": "1",
               "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
        stdout_path, stderr_path = ctl / "stdout.txt", ctl / "stderr.txt"
        with stdout_path.open("wb") as fout, stderr_path.open("wb") as ferr:
            proc = subprocess.Popen(
                [sys.executable, "-I", "-B", str(ctl / "harness.py"), str(ctl)],
                cwd=str(work), env=env, stdin=subprocess.DEVNULL, stdout=fout, stderr=ferr,
                close_fds=True, start_new_session=True)
            try:
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait()
                return {"timeout": True}
            finally:
                try:                                      # dọn mọi tiến trình con còn sót
                    os.killpg(proc.pid, signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    pass
        stderr_tail = _read_tail(stderr_path).replace(str(root), "<sandbox>")
        result_path = ctl / "result.json"
        try:
            size = result_path.stat().st_size
        except OSError:
            return {"crash": True, "stderr": stderr_tail}
        if size == 0 or size > PY_SANDBOX_MAX_RESULT_BYTES:
            return {"crash": True, "stderr": stderr_tail or "Kết quả rỗng hoặc quá lớn"}
        try:
            data = json.loads(result_path.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            return {"crash": True, "stderr": stderr_tail}
        if not _valid_sandbox_result(data, cases, nonce):
            return {"crash": True, "stderr": "Kết quả từ tiến trình chấm không hợp lệ"}
        return data


def _normalize_py_records(records: list[dict], columns: list[str]) -> Optional[set[tuple]]:
    """Chuyển kết quả của học viên về tập (customer_id, 'YYYY-MM', revenue) không phụ thuộc tên cột revenue."""
    out: set[tuple] = set()
    for rec in records:
        cust = rec.get("customer_id")
        month = None
        for key in ("month", "order_month", "year_month", "order_date", "period"):
            if key in rec and rec[key] is not None:
                month = str(rec[key])[:7]
                break
        revenue = None
        for key in ("revenue", "amount", "total", "total_revenue", "monthly_revenue", "sum"):
            if key in rec and isinstance(rec[key], (int, float)):
                revenue = float(rec[key])
                break
        if revenue is None:
            nums = [v for k, v in rec.items() if k not in ("customer_id",) and isinstance(v, (int, float)) and not isinstance(v, bool)]
            revenue = float(nums[-1]) if nums else None
        if cust is None or month is None or revenue is None:
            return None
        out.add((cust, month, round(revenue, 6)))
    return out


def grade_python_answer(code: str) -> CodeGrade:
    """B-P1: 6 test case trọng số bằng nhau (đã công bố). Điểm thô = 4 * tỷ lệ test đạt."""
    try:
        import pandas as pd
    except ImportError:
        return CodeGrade(0.0, ["Thiếu pandas trong môi trường chấm"], infrastructure_error=True)
    if not isinstance(code, str) or not code.strip():
        return CodeGrade(0.0, ["Bài làm trống"])
    if len(code) > MAX_CODE_CHARS:
        return CodeGrade(0.0, [f"Code dài quá {MAX_CODE_CHARS} ký tự"])
    raw = run_python_sandboxed(code, PYTHON_TEST_CASES)
    if raw.get("unsupported"):
        return CodeGrade(0.0, [str(raw["unsupported"])], infrastructure_error=True)
    if raw.get("timeout"):
        return CodeGrade(0.0, ["Code vượt quá thời gian cho phép"])
    if raw.get("crash"):
        return CodeGrade(0.0, [f"Tiến trình chấm bị dừng (có thể do vượt giới hạn tài nguyên): {raw.get('stderr', '')}"])
    if raw.get("import_error"):
        return CodeGrade(0.0, [raw["import_error"]])
    passed, detail = 0, []
    for case, got in zip(PYTHON_TEST_CASES, raw["cases"]):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")          # định dạng ngày lỗi là chủ ý của test case
            expected_df, _ = monthly_revenue_by_customer_reference(pd.DataFrame(case["rows"], columns=_COLS))
        expected = {(r.customer_id, str(r.month)[:7], round(float(r.revenue), 6)) for r in expected_df.itertuples()}
        if got["error"]:
            detail.append(f"{case['name']}: lỗi {got['error']}")
            continue
        actual = _normalize_py_records(got["records"] or [], got.get("columns", []))
        if actual is not None and actual == expected:
            passed += 1
            detail.append(f"{case['name']}: đạt")
        else:
            detail.append(f"{case['name']}: sai kết quả")
    return CodeGrade(4.0 * passed / len(PYTHON_TEST_CASES), detail)
