"""question_bank.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import hashlib
import math
import random
from dataclasses import dataclass
from typing import Iterable, Optional

from .rubrics import RUBRICS

# --------------------------------------------------------------------------------------
# 3. Question bank (mục 3)
# --------------------------------------------------------------------------------------

Kind = str  # "mcq" | "essay" | "sql" | "python" | "stats" | "self_report"


@dataclass(frozen=True)
class Question:
    question_id: str
    skill: Optional[str]                 # None cho A-P1/A-P2 (không tính điểm)
    kind: Kind
    prompt: str
    options: tuple[tuple[str, str], ...] = ()    # (option_id, text)
    answer_option_id: Optional[str] = None
    rubric_id: Optional[str] = None
    code_share: float = 0.0              # phần điểm do code chấm
    reference_answer: str = ""           # CHỈ backend; không gửi cho học viên
    scored: bool = True

    @property
    def ai_share(self) -> float:
        return round(1.0 - self.code_share, 10)

    def public_view(self, attempt_seed: str) -> dict:
        """Phần gửi cho client: không có đáp án/đáp án tham chiếu."""
        view = {"question_id": self.question_id, "kind": self.kind, "prompt": self.prompt}
        if self.options:
            view["options"] = present_options(self, attempt_seed)
        return view


def _mcq(qid: str, skill: str, prompt: str, options: dict[str, str], answer: str) -> Question:
    if answer not in options:
        raise ValueError(f"{qid}: đáp án {answer!r} không nằm trong option_id")
    return Question(qid, skill, "mcq", prompt, tuple(options.items()), answer_option_id=answer, code_share=1.0)


def _essay(qid: str, skill: str, prompt: str, rubric_id: str, ref: str) -> Question:
    return Question(qid, skill, "essay", prompt, rubric_id=rubric_id, code_share=0.0, reference_answer=ref)


QUESTIONS: dict[str, Question] = {q.question_id: q for q in (
    # ---- Người mới ----
    _mcq("A-T1", "A-STAT",
         "Doanh thu 5 cửa hàng (triệu đồng) là 10, 12, 11, 13, 100. Đại lượng nào đại diện tốt nhất cho doanh thu “điển hình”?",
         {"mean": "Trung bình", "median": "Trung vị", "maximum": "Lớn nhất", "minimum": "Nhỏ nhất"}, "median"),
    _mcq("A-T2", "A-STAT", "Cột nào là dữ liệu phân loại (categorical)?",
         {"revenue": "Doanh thu", "order_count": "Số đơn hàng", "payment_method": "Phương thức thanh toán",
          "delivery_time": "Thời gian giao hàng"}, "payment_method"),
    _mcq("A-T3", "A-STAT",
         "Doanh số kem và số vụ đuối nước cùng tăng vào mùa hè. Kết luận phù hợp nhất?",
         {"ice_cream_causes_drowning": "Kem gây đuối nước",
          "drowning_increases_ice_cream": "Đuối nước làm tăng doanh số kem",
          "weather_confounder": "Thời tiết nóng có thể ảnh hưởng cả hai",
          "unrelated": "Hai thứ không liên quan"}, "weather_confounder"),
    _mcq("A-T4", "A-STAT",
         "Hai cửa hàng đều có doanh thu trung bình 100 triệu/tháng. Độ lệch chuẩn của A là 5, của B là 40. Nhận định nào đúng?",
         {"store_A_more_variability": "A biến động hơn", "store_B_more_variability": "B biến động hơn",
          "same_variability": "Giống nhau", "B_higher_mean": "B có doanh thu trung bình cao hơn"},
         "store_B_more_variability"),
    _essay("A-T5", "A-STAT",
           "Giải thích bằng lời của bạn: trung bình (mean) và trung vị (median) khác nhau thế nào? Khi nào nên dùng trung vị? Hãy cho một ví dụ.",
           "A1",
           "Mean là tổng chia số quan sát, nhạy với giá trị cực đoan; median là giá trị ở giữa sau khi sắp xếp và ít bị "
           "ảnh hưởng hơn bởi ngoại lai. Có thể dùng median với phân phối lệch/thu nhập/giá nhà."),
    _essay("A-T6", "A-STAT",
           "Tương quan và nhân quả khác nhau thế nào? Nêu một ví dụ hai thứ tương quan nhưng không nhất thiết có quan hệ nhân quả.",
           "A1",
           "Tương quan mô tả hai biến thay đổi cùng nhau; nhân quả là một biến gây thay đổi biến kia. Ví dụ kem và đuối "
           "nước cùng tăng do thời tiết nóng; cần thiết kế nghiên cứu/kiểm soát yếu tố gây nhiễu để lập luận nhân quả."),
    _mcq("A-X1", "A-XLS", "Có 10.000 dòng đơn hàng và cần tổng doanh thu theo khu vực và tháng. Công cụ nhanh, phù hợp nhất?",
         {"manual_sum": "Lọc rồi cộng tay", "pivot_table": "PivotTable", "pie_chart": "Biểu đồ tròn", "concat": "CONCAT"},
         "pivot_table"),
    _mcq("A-X2", "A-XLS", "Biểu đồ nào phù hợp nhất để xem xu hướng doanh thu 12 tháng?",
         {"pie": "Tròn", "line": "Đường", "scatter": "Phân tán", "3d_area": "Vùng 3D"}, "line"),
    _mcq("A-X3", "A-XLS", "Cần so sánh doanh thu của 8 sản phẩm có tên dài. Chọn phương án tốt nhất?",
         {"pie_8": "Biểu đồ tròn 8 phần", "horizontal_bar": "Cột ngang xếp giảm dần", "line": "Đường", "radar": "Radar"},
         "horizontal_bar"),
    _mcq("A-X4", "A-XLS", "Bảng giá theo mã sản phẩm nằm ở sheet khác; cần dò giá vào bảng đơn hàng. Hàm phù hợp?",
         {"sumif": "SUMIF", "lookup": "XLOOKUP hoặc VLOOKUP", "countif": "COUNTIF", "round": "ROUND"}, "lookup"),
    Question("A-S1", "A-SQL", "sql", "Liệt kê tên và thành phố của khách hàng ở Hà Nội.", code_share=1.0),
    Question("A-S2", "A-SQL", "sql", "Đếm số đơn hàng có trạng thái completed.", code_share=1.0),
    Question("A-S3", "A-SQL", "sql", "Tính tổng doanh thu (chỉ đơn completed) theo thành phố, xếp từ cao xuống thấp.", code_share=1.0),
    Question("A-S4", "A-SQL", "sql", "Tìm 3 khách hàng có tổng chi tiêu completed cao nhất.", code_share=1.0),
    Question("A-S5", "A-SQL", "sql", "Tìm khách hàng chưa từng đặt đơn nào.", code_share=1.0),
    _essay("A-R1", "A-READ",
           "Doanh thu sáu tháng đầu năm (triệu đồng): T1 120, T2 135, T3 128, T4 140, T5 60, T6 145. Viết 2-3 câu nhận xét.",
           "A2",
           "Xu hướng tăng nhẹ đầu kỳ đến cuối kỳ; T5 giảm từ 140 xuống 60 (khoảng -57,1%); T6 phục hồi. Không khẳng định "
           "nguyên nhân; đề xuất kiểm tra lỗi dữ liệu, tồn kho, chiến dịch hoặc sự kiện."),
    _essay("A-R2", "A-READ",
           "Facebook: 10.000 lượt truy cập, 200 đơn. Google: 4.000 lượt, 160 đơn. Email: 500 lượt, 50 đơn. Kênh nào hiệu quả nhất?",
           "A2",
           "Tỷ lệ chuyển đổi: Facebook 2%, Google 4%, Email 10%. Email cao nhất nhưng mẫu nhỏ; Facebook nhiều đơn nhất "
           "nhưng tỷ lệ thấp nhất. Cần thêm chi phí/biên lợi nhuận và độ bất định."),
    _essay("A-R3", "A-READ",
           "Bảng: nhóm 18-24 tuổi chiếm 30% khách, chi tiêu trung bình 200 nghìn; nhóm 25-34 chiếm 45%, chi tiêu trung bình "
           "450 nghìn; nhóm 35+ chiếm 25%, chi tiêu trung bình 380 nghìn. Một bạn nói “quảng cáo khiến nhóm 25-34 mua nhiều hơn”. Nhận xét?",
           "A2",
           "Nhóm 25-34 chiếm tỷ lệ khách lớn nhất và chi tiêu trung bình cao nhất; bảng không có thông tin phơi nhiễm quảng "
           "cáo nên không chứng minh nhân quả. Cần dữ liệu quảng cáo/đối chứng hoặc thử nghiệm."),
    Question("A-P1", None, "self_report",
             "Bạn đã từng dùng Excel, SQL hoặc Python chưa? (chưa dùng / biết cơ bản / đã dùng trong bài tập/dự án / đã dùng cho công việc)",
             options=(("none", "Chưa dùng"), ("basic", "Biết cơ bản"), ("project", "Đã dùng trong bài tập/dự án"),
                      ("work", "Đã dùng cho công việc")), scored=False),
    Question("A-P2", None, "self_report",
             "Bạn có thể học bao nhiêu giờ mỗi tuần? Mục tiêu là tìm việc trong bao lâu, chuyển ngành hay nâng cao công việc hiện tại?",
             scored=False),
    # ---- Xin việc ----
    Question("B-S1", "B-SQL", "sql", "Tìm các sản phẩm thuộc top 3 doanh thu trong từng danh mục, chỉ tính đơn completed. "
             "Đồng hạng: trả mọi sản phẩm có RANK() <= 3.", rubric_id="B2", code_share=0.70),
    Question("B-S2", "B-SQL", "sql", "Tính tỷ lệ khách hàng mua lại trong vòng 30 ngày kể từ đơn completed đầu tiên.",
             rubric_id="B2", code_share=0.70),
    Question("B-S3", "B-SQL", "sql", "Tính doanh thu từng tháng và phần trăm tăng/giảm so với tháng trước.",
             rubric_id="B2", code_share=0.70),
    Question("B-S4", "B-SQL", "sql", "Bảng orders có order_id trùng. Viết truy vấn tìm order_id trùng và truy vấn giữ lại một dòng cho mỗi order_id.",
             rubric_id="B2", code_share=0.70),
    Question("B-P1", "B-PY", "python",
             "DataFrame df có customer_id, order_date, amount; có dòng trùng và amount bị thiếu. Viết hàm monthly_revenue_by_customer(df) "
             "làm sạch (nêu lý do xử lý thiếu dữ liệu) và tính tổng doanh thu mỗi khách theo từng tháng.",
             rubric_id="B3", code_share=0.70),
    Question("B-P2", "B-PY", "stats",
             "Thử nghiệm A/B: nhóm A có 500 đơn trên 10.000 lượt (5,0%), nhóm B có 550 đơn trên 10.000 lượt (5,5%). "
             "Có nên triển khai B? Giải thích bằng kiểm định phù hợp.",
             rubric_id="B3", code_share=0.70),
    _essay("B-C1", "B-CASE", "Doanh thu tuần này giảm 15% so với tuần trước. Bạn phân tích như thế nào?", "B1",
           "Làm rõ định nghĩa doanh thu/phạm vi/timezone; tách doanh thu = phiên × chuyển đổi × giá trị đơn; cắt theo kênh, "
           "sản phẩm, khu vực, thiết bị; kiểm tra nguyên nhân nội bộ và bên ngoài; đề xuất hành động có ưu tiên."),
    _essay("B-C2", "B-CASE", "Công ty ra tính năng “gợi ý sản phẩm liên quan” trên trang chi tiết. Chọn metric nào để đo thành công?", "B1",
           "Metric chính phù hợp mục tiêu (doanh thu/phiên đủ điều kiện hoặc tỷ lệ mua); metric dẫn dắt CTR; metric bảo vệ "
           "(tốc độ tải, thoát trang, hoàn/hủy); kế hoạch A/B test, randomization, thời gian chạy, phân khúc."),
    _essay("B-C3", "B-CASE", "Tỷ lệ hủy đơn tăng từ 5% lên 8% sau khi đổi chính sách phí vận chuyển. Bạn xử lý thế nào?", "B1",
           "Xác nhận thay đổi là thật (cỡ mẫu, mùa vụ, tracking); phân tích lý do/phân khúc/giá trị giỏ; đánh đổi doanh thu "
           "phí ship và đơn mất; đề xuất A/B hoặc điều chỉnh có điều kiện; metric chính và bảo vệ."),
    _essay("B-V1", "B-VIZ",
           "Thiết kế dashboard cho trưởng phòng bán hàng họp vào sáng thứ Hai. Mô tả 4-6 chỉ số, loại biểu đồ cho từng chỉ số và bộ lọc.",
           "BVIZ",
           "KPI gắn quyết định (doanh thu so mục tiêu, đơn mới, chuyển đổi, doanh thu theo khu vực, top sản phẩm); KPI card, "
           "line cho xu hướng, bar cho so sánh; bộ lọc thời gian/khu vực; cảnh báo khi lệch mục tiêu và hành động."),
    _essay("B-M1", "B-COM", "Mô tả một dự án phân tích bạn từng làm (hoặc dự án mẫu nếu chưa có) theo STAR, 150-250 từ. "
           "Nếu là dự án mẫu, ghi rõ “bài luyện tập”.", "B4",
           "S/T/A/R rõ ràng, vai trò cá nhân, metric đo được, nhất quán khi hỏi đào sâu."),
    _essay("B-M2", "B-COM", "Kết quả B-P2 cần báo cáo cho giám đốc marketing không rành thống kê. Viết thông điệp dưới 120 từ.", "B5",
           "Chênh lệch quan sát +0,5 điểm phần trăm; chưa đủ bằng chứng kết luận B tốt hơn A; khoảng bất định còn gồm không "
           "cải thiện; đề xuất thêm mẫu/đánh giá chi phí. Tránh khẳng định “không có tác động”."),
)}

# Yêu cầu độ dài riêng của từng câu (mục 3.2); chỉ là kiểm tra bằng code, không đổi rubric.
WORD_LIMITS: dict[str, tuple[int, int]] = {"B-M1": (150, 250), "B-M2": (0, 119)}

BEGINNER_SKILLS = ("A-STAT", "A-XLS", "A-SQL", "A-READ")
BEGINNER_WEIGHTS = {"A-STAT": 0.30, "A-XLS": 0.20, "A-SQL": 0.30, "A-READ": 0.20}
JOB_SKILLS = ("B-SQL", "B-PY", "B-CASE", "B-VIZ", "B-COM")
ROLE_WEIGHTS: dict[str, dict[str, float]] = {
    "Business Analyst":          {"B-SQL": 0.20, "B-PY": 0.15, "B-CASE": 0.30, "B-VIZ": 0.10, "B-COM": 0.25},
    "BI Analyst":                {"B-SQL": 0.30, "B-PY": 0.10, "B-CASE": 0.15, "B-VIZ": 0.30, "B-COM": 0.15},
    "Product/Marketing Analyst": {"B-SQL": 0.20, "B-PY": 0.20, "B-CASE": 0.30, "B-VIZ": 0.10, "B-COM": 0.20},
}
ROLE_QUESTIONS: dict[str, tuple[str, ...]] = {
    "Business Analyst": ("B-S1", "B-V1", "B-P2", "B-C1", "B-C2", "B-C3", "B-M1", "B-M2"),
    "BI Analyst": ("B-S1", "B-S2", "B-S3", "B-S4", "B-P1", "B-V1", "B-C1", "B-M2"),
    "Product/Marketing Analyst": ("B-S2", "B-S3", "B-P2", "B-C1", "B-C2", "B-C3", "B-V1", "B-M1"),
}
BEGINNER_QUESTIONS = tuple(q for q in QUESTIONS if q.startswith("A-") and QUESTIONS[q].scored)


def validate_question_bank() -> None:
    """Checklist Phụ lục A: câu hỏi nhất quán, rubric tồn tại, tổng trọng số kỹ năng = 1.0."""
    for qid, q in QUESTIONS.items():
        if qid != q.question_id:
            raise ValueError(f"Khóa câu hỏi {qid} khác question_id {q.question_id}")
        if q.rubric_id is not None and q.rubric_id not in RUBRICS:
            raise ValueError(f"{qid}: rubric {q.rubric_id} không tồn tại")
        if q.kind == "essay" and q.rubric_id is None:
            raise ValueError(f"{qid}: tự luận phải có rubric")
        if not 0.0 <= q.code_share <= 1.0:
            raise ValueError(f"{qid}: code_share ngoài [0,1]")
    if len(BEGINNER_QUESTIONS) != 18:
        raise ValueError(f"Nhóm Người mới phải có 18 câu tính điểm, hiện có {len(BEGINNER_QUESTIONS)}")
    if not math.isclose(sum(BEGINNER_WEIGHTS.values()), 1.0, abs_tol=1e-9):
        raise ValueError("Trọng số kỹ năng Người mới không bằng 1.0")
    for role, weights in ROLE_WEIGHTS.items():
        if not math.isclose(sum(weights.values()), 1.0, abs_tol=1e-9):
            raise ValueError(f"Trọng số vị trí {role} không bằng 1.0")
        qids = ROLE_QUESTIONS[role]
        if len(qids) != 8 or len(set(qids)) != 8:
            raise ValueError(f"{role}: phải có đúng 8 câu khác nhau")
        covered = {QUESTIONS[q].skill for q in qids}
        if covered != set(weights):
            raise ValueError(f"{role}: bộ câu không phủ đúng các kỹ năng có trọng số ({covered} vs {set(weights)})")


def skill_question_counts(question_ids: Iterable[str]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for qid in question_ids:
        q = QUESTIONS[qid]
        if q.scored and q.skill:
            counts[q.skill] = counts.get(q.skill, 0) + 1
    return counts


def deterministic_rng(attempt_seed: str, question_id: str) -> random.Random:
    digest = hashlib.sha256(f"{attempt_seed}|{question_id}".encode("utf-8")).digest()
    return random.Random(int.from_bytes(digest[:8], "big"))


def present_options(question: Question, attempt_seed: str) -> list[dict]:
    """Xáo thứ tự hiển thị, option_id bất biến (mục 3.3). Lưu kết quả này vào audit."""
    options = list(question.options)
    deterministic_rng(attempt_seed, question.question_id).shuffle(options)
    return [{"display_label": chr(ord("A") + i), "option_id": oid, "text": text}
            for i, (oid, text) in enumerate(options)]


def grade_mcq(question: Question, submitted_option_id: Optional[str]) -> float:
    """Điểm thô 0-4: so option_id, không bao giờ so chữ cái A/B/C/D."""
    if question.kind != "mcq" or question.answer_option_id is None:
        raise ValueError(f"{question.question_id} không phải câu trắc nghiệm")
    valid = {oid for oid, _ in question.options}
    if submitted_option_id is not None and submitted_option_id not in valid:
        raise ValueError(f"option_id {submitted_option_id!r} không hợp lệ cho {question.question_id}")
    return 4.0 if submitted_option_id == question.answer_option_id else 0.0
