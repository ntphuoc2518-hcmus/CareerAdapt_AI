"""stats_grader.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import math
import re
from typing import Optional

from .text_utils import nfc
from .sql_grader import CodeGrade

# --------------------------------------------------------------------------------------
# 8. Kiểm tra con số B-P2 (A/B test hai tỷ lệ) và các phép tính nhận xét A-R1/A-R2
# --------------------------------------------------------------------------------------

STATS_TOLERANCE = {"z": 0.05, "p": 0.01, "ci_pp": 0.05}    # cấu hình được; ci tính bằng điểm phần trăm


def two_proportion_reference(x_a: int = 500, n_a: int = 10_000, x_b: int = 550, n_b: int = 10_000) -> dict:
    pa, pb = x_a / n_a, x_b / n_b
    pooled = (x_a + x_b) / (n_a + n_b)
    se_pooled = math.sqrt(pooled * (1 - pooled) * (1 / n_a + 1 / n_b))
    z = (pb - pa) / se_pooled
    p_value = math.erfc(abs(z) / math.sqrt(2))          # hai phía
    se_unpooled = math.sqrt(pa * (1 - pa) / n_a + pb * (1 - pb) / n_b)
    half = 1.959963984540054 * se_unpooled
    return {"z": z, "p_value": p_value, "ci_low_pp": (pb - pa - half) * 100, "ci_high_pp": (pb - pa + half) * 100,
            "diff_pp": (pb - pa) * 100}


_NUM_RE = re.compile(r"(?<![\w.])[-−–]?\d+(?:[.,]\d+)?")


def extract_numbers(text: str) -> list[float]:
    values = []
    for token in _NUM_RE.findall(nfc(text)):
        token = token.replace("−", "-").replace("–", "-").replace(",", ".")
        try:
            values.append(float(token))
        except ValueError:
            continue
    return values


def grade_ab_test_answer(answer: str, tolerance: dict = STATS_TOLERANCE) -> CodeGrade:
    """70% điểm B-P2: xác minh z, p-value, khoảng tin cậy bằng code. Điểm thô = 4 * (số mục đạt / 3)."""
    ref = two_proportion_reference()
    nums = extract_numbers(answer)

    def near(target: float, tol: float) -> bool:
        return any(abs(v - target) <= tol for v in nums)

    z_ok = near(ref["z"], tolerance["z"])
    p_ok = near(ref["p_value"], tolerance["p"])
    ci_tol_pp, ci_tol_frac = tolerance["ci_pp"], tolerance["ci_pp"] / 100
    low_ok = near(ref["ci_low_pp"], ci_tol_pp) or near(ref["ci_low_pp"] / 100, ci_tol_frac)
    high_ok = near(ref["ci_high_pp"], ci_tol_pp) or near(ref["ci_high_pp"] / 100, ci_tol_frac)
    ci_ok = low_ok and high_ok
    hits = sum([z_ok, p_ok, ci_ok])
    detail = [f"z≈{ref['z']:.3f}: {'đạt' if z_ok else 'thiếu/sai'}",
              f"p≈{ref['p_value']:.4f}: {'đạt' if p_ok else 'thiếu/sai'}",
              f"CI 95% chênh lệch [{ref['ci_low_pp']:.2f}; {ref['ci_high_pp']:.2f}] điểm %: {'đạt' if ci_ok else 'thiếu/sai'}"]
    return CodeGrade(4.0 * hits / 3.0, detail)


def code_verified_facts(question_id: str) -> Optional[dict]:
    """Sự kiện đã xác minh bằng code, gửi kèm cho LLM để B3-INTERPRET mức 0 ('trái kết quả code xác minh')."""
    if question_id == "B-P2":
        ref = two_proportion_reference()
        return {k: round(v, 4) for k, v in ref.items()} | {"significant_at_0.05": ref["p_value"] < 0.05}
    if question_id == "A-R1":
        return {"t5_change_pct": round((60 - 140) / 140 * 100, 1)}
    if question_id == "A-R2":
        return {"conversion_pct": {"Facebook": 200 / 10000 * 100, "Google": 160 / 4000 * 100, "Email": 50 / 500 * 100}}
    return None
