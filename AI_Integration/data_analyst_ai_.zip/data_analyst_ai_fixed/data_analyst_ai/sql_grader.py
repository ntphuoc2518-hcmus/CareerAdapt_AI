"""sql_grader.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import math
import re
import sqlite3
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Sequence

from .config import GradingError
from .fixtures import build_a_fixture, build_b_fixture
from .sql_sandbox import SqlExecutionError, SqlRejected, SqlResult, run_readonly_query, split_statements

# --------------------------------------------------------------------------------------
# 6. So khớp kết quả SQL và quy đổi sang điểm thô 0-4 (mục "Quy tắc chấm SQL cơ bản")
# --------------------------------------------------------------------------------------

MAX_PROJECTION_CANDIDATES = 50_000       # chặn bùng nổ tổ hợp khi thử chọn/sắp cột


@dataclass(frozen=True)
class SqlContract:
    ordered: bool = False
    float_tol: float = 1e-6


def _cell_key(v: Any) -> tuple:
    if v is None:
        return (0, "")
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return (1, round(float(v), 4))
    return (2, str(v))


def _cells_close(a: Any, b: Any, tol: float) -> bool:
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool) and not isinstance(b, bool):
        return abs(float(a) - float(b)) <= tol
    return str(a) == str(b)


def _rows_equal(a: list[tuple], b: list[tuple], ordered: bool, tol: float) -> bool:
    if len(a) != len(b):
        return False
    if not ordered:
        a = sorted(a, key=lambda r: tuple(_cell_key(c) for c in r))
        b = sorted(b, key=lambda r: tuple(_cell_key(c) for c in r))
    return all(len(x) == len(y) and all(_cells_close(i, j, tol) for i, j in zip(x, y)) for x, y in zip(a, b))


def _project(rows: list[tuple], idx: Sequence[int]) -> list[tuple]:
    return [tuple(r[i] for i in idx) for r in rows]


def _best_projection(expected: SqlResult, actual: SqlResult, contract: SqlContract) -> Optional[tuple[int, ...]]:
    """Tìm cách chọn/sắp cột của `actual` để khớp toàn bộ `expected` (không phụ thuộc alias)."""
    from itertools import permutations
    e_w, a_w = len(expected.columns), len(actual.columns)
    if a_w < e_w or a_w > 8 or math.perm(a_w, e_w) > MAX_PROJECTION_CANDIDATES:
        return None
    for idx in permutations(range(a_w), e_w):
        if _rows_equal(expected.rows, _project(actual.rows, idx), contract.ordered, contract.float_tol):
            return idx
    return None


def score_sql_result(expected: SqlResult, actual: SqlResult, contract: SqlContract) -> tuple[int, str]:
    """Điểm thô 0-4 cho một kết quả SQL đã chạy được."""
    e_w, a_w = len(expected.columns), len(actual.columns)
    # Bước 1: khớp hoàn toàn (kể cả thứ tự nếu bắt buộc)
    idx = _best_projection(expected, actual, contract)
    if idx is not None:
        return (4, "Khớp hoàn toàn") if a_w == e_w else (3, "Đúng dữ liệu nhưng thừa cột")
    # Bước 2: đúng dữ liệu nhưng sai thứ tự bắt buộc
    if contract.ordered:
        relaxed = SqlContract(ordered=False, float_tol=contract.float_tol)
        if _best_projection(expected, actual, relaxed) is not None:
            return 3, "Đúng dữ liệu nhưng sai thứ tự yêu cầu"
    # Bước 3: thiếu đúng một cột không cốt yếu (chỉ khi đề có >= 3 cột)
    if e_w >= 3 and a_w == e_w - 1:
        from itertools import combinations, permutations
        for keep in combinations(range(e_w), a_w):
            sub = SqlResult([expected.columns[i] for i in keep], _project(expected.rows, keep), expected.tables_read)
            for perm in permutations(range(a_w)):
                if _rows_equal(sub.rows, _project(actual.rows, perm), contract.ordered, contract.float_tol):
                    return 3, "Đúng dữ liệu nhưng thiếu một cột không cốt yếu"
    # Bước 4: sai lệch nhỏ (< 20% số dòng) và đúng bảng
    if a_w == e_w and expected.tables_read <= actual.tables_read:
        def keyed(rows: list[tuple]) -> list[tuple]:
            return sorted((tuple(_cell_key(c) for c in r) for r in rows))
        exp_keys, act_keys = keyed(expected.rows), keyed(actual.rows)
        remaining = list(act_keys)
        matched = 0
        for k in exp_keys:
            if k in remaining:
                remaining.remove(k)
                matched += 1
        denominator = max(len(exp_keys), 1)
        diff_ratio = (len(exp_keys) - matched + len(remaining)) / denominator
        if diff_ratio < 0.20 and matched > 0:
            return 2, "Đúng bảng và điều kiện chính, sai lệch nhỏ"
    return 1, "Chạy được nhưng kết quả sai đáng kể"


_SELECT_START_RE = re.compile(r"^\s*(select|with)\b", re.IGNORECASE)


def _static_idea_recognizable(sql: str, expected_tables: set[str]) -> bool:
    """Phân tích tĩnh rất nhẹ cho lỗi cú pháp nhỏ: có SELECT/WITH và nhắc đủ bảng cần dùng."""
    lowered = sql.lower()
    return bool(_SELECT_START_RE.match(sql)) and all(re.search(rf"\b{re.escape(t)}\b", lowered) for t in expected_tables)


REFERENCE_SQL: dict[str, Any] = {
    "A-S1": "SELECT name, city FROM customers WHERE city = 'Hà Nội';",
    "A-S2": "SELECT COUNT(*) FROM orders WHERE status = 'completed';",
    "A-S3": """SELECT c.city, SUM(o.amount) AS revenue FROM customers AS c
               JOIN orders AS o ON o.customer_id = c.customer_id WHERE o.status = 'completed'
               GROUP BY c.city ORDER BY revenue DESC;""",
    "A-S4": """SELECT c.name, SUM(o.amount) AS total_spent FROM customers AS c
               JOIN orders AS o ON o.customer_id = c.customer_id WHERE o.status = 'completed'
               GROUP BY c.customer_id, c.name ORDER BY total_spent DESC, c.customer_id ASC LIMIT 3;""",
    "A-S5": """SELECT c.name FROM customers AS c LEFT JOIN orders AS o ON o.customer_id = c.customer_id
               WHERE o.order_id IS NULL;""",
    "B-S1": """WITH revenue AS (
                 SELECT p.category, p.product_id, p.product_name, SUM(o.quantity * o.unit_price) AS revenue
                 FROM orders AS o JOIN products AS p ON p.product_id = o.product_id
                 WHERE o.status = 'completed' GROUP BY p.category, p.product_id, p.product_name
               ), ranked AS (
                 SELECT revenue.*, RANK() OVER (PARTITION BY category ORDER BY revenue DESC) AS revenue_rank FROM revenue
               )
               SELECT category, product_id, product_name, revenue, revenue_rank FROM ranked
               WHERE revenue_rank <= 3 ORDER BY category, revenue_rank, product_id;""",
    "B-S2": """WITH first_order AS (
                 SELECT customer_id, MIN(date(order_date)) AS first_date FROM orders
                 WHERE status = 'completed' GROUP BY customer_id
               ), repeaters AS (
                 SELECT DISTINCT f.customer_id FROM first_order AS f JOIN orders AS o ON o.customer_id = f.customer_id
                 WHERE o.status = 'completed' AND date(o.order_date) > date(f.first_date)
                   AND date(o.order_date) <= date(f.first_date, '+30 day')
               )
               SELECT ROUND(100.0 * (SELECT COUNT(*) FROM repeaters)
                      / NULLIF((SELECT COUNT(*) FROM first_order), 0), 1) AS repurchase_rate_30d;""",
    "B-S3": """WITH RECURSIVE bounds AS (
                 SELECT strftime('%Y-%m-01', MIN(order_date)) AS min_month, strftime('%Y-%m-01', MAX(order_date)) AS max_month
                 FROM orders WHERE status = 'completed'
               ), months(month) AS (
                 SELECT min_month FROM bounds WHERE min_month IS NOT NULL
                 UNION ALL
                 SELECT strftime('%Y-%m-01', date(month, '+1 month')) FROM months, bounds WHERE month < max_month
               ), monthly AS (
                 SELECT strftime('%Y-%m-01', order_date) AS month, SUM(quantity * unit_price) AS revenue
                 FROM orders WHERE status = 'completed' GROUP BY strftime('%Y-%m-01', order_date)
               ), filled AS (
                 SELECT m.month, COALESCE(r.revenue, 0) AS revenue FROM months AS m LEFT JOIN monthly AS r ON r.month = m.month
               ), lagged AS (
                 SELECT month, revenue, LAG(revenue) OVER (ORDER BY month) AS previous_revenue FROM filled
               )
               SELECT month, revenue,
                      CASE WHEN previous_revenue IS NULL OR previous_revenue = 0 THEN NULL
                           ELSE ROUND(100.0 * (revenue - previous_revenue) / previous_revenue, 1) END AS mom_pct
               FROM lagged ORDER BY month;""",
    "B-S4": {
        "find": "SELECT order_id, COUNT(*) AS n FROM orders GROUP BY order_id HAVING COUNT(*) > 1;",
        "dedupe": """WITH ranked AS (
                       SELECT rowid AS source_rowid, orders.*,
                              ROW_NUMBER() OVER (PARTITION BY order_id ORDER BY date(order_date), rowid) AS rn
                       FROM orders)
                     SELECT order_id, customer_id, product_id, order_date, quantity, unit_price, status
                     FROM ranked WHERE rn = 1;""",
    },
}

SQL_CONTRACTS: dict[str, Any] = {
    "A-S1": SqlContract(), "A-S2": SqlContract(),
    "A-S3": SqlContract(ordered=True),             # đề yêu cầu bắt buộc ORDER BY doanh thu giảm dần
    "A-S4": SqlContract(), "A-S5": SqlContract(),
    "B-S1": SqlContract(),
    "B-S2": SqlContract(float_tol=0.051),
    "B-S3": SqlContract(float_tol=0.051),
    "B-S4": {"find": SqlContract(), "dedupe": SqlContract()},
}


def _datasets_for(qid: str) -> list[tuple[str, Callable[[], sqlite3.Connection]]]:
    if qid.startswith("A-"):
        return [("base", lambda: build_a_fixture("base")), ("edge", lambda: build_a_fixture("edge"))]
    if qid == "B-S4":
        return [("duplicates", lambda: build_b_fixture(with_duplicates=True))]
    return [("base", lambda: build_b_fixture()), ("alt", lambda: build_b_fixture(variant="alt"))]


@dataclass
class CodeGrade:
    raw_score: float                     # thang 0-4
    detail: list[str] = field(default_factory=list)
    infrastructure_error: bool = False   # True: hệ thống chấm lỗi -> chuyển người chấm, không phạt học viên


def _grade_one_sql(conn_factory: Callable[[], sqlite3.Connection], reference: str, student_sql: str,
                   contract: SqlContract) -> tuple[int, str]:
    ref_conn = conn_factory()
    stu_conn = conn_factory()
    try:
        try:
            expected = run_readonly_query(ref_conn, reference)
        except (SqlRejected, SqlExecutionError) as exc:       # lỗi fixture/đáp án chuẩn: lỗi hệ thống
            raise GradingError(f"Đáp án chuẩn không chạy được: {exc}") from exc
        try:
            actual = run_readonly_query(stu_conn, student_sql)
        except SqlRejected as exc:
            return 0, f"Bị từ chối: {exc}"
        except SqlExecutionError as exc:
            if exc.syntax and _static_idea_recognizable(student_sql, expected.tables_read):
                return 1, f"Lỗi cú pháp nhưng ý tưởng nhận diện được: {exc}"
            return 0, f"Lỗi truy vấn: {exc}"
        if not actual.rows and expected.rows:
            return 0, "Truy vấn trả về tập rỗng trong khi đáp án có dữ liệu"
        return score_sql_result(expected, actual, contract)
    finally:
        ref_conn.close()
        stu_conn.close()


def grade_sql_answer(question_id: str, answer: Any) -> CodeGrade:
    """Chấm SQL bằng cách chạy trên mọi dataset của câu và lấy điểm THẤP NHẤT (chống hard-code)."""
    if question_id not in REFERENCE_SQL:
        raise ValueError(f"{question_id} không có đáp án SQL chuẩn")
    reference, contract = REFERENCE_SQL[question_id], SQL_CONTRACTS[question_id]
    parts: dict[str, tuple[str, SqlContract]]
    if isinstance(reference, dict):
        if isinstance(answer, str):
            stmts = split_statements(answer)
            if len(stmts) != len(reference):
                return CodeGrade(0.0, [f"Cần đúng {len(reference)} truy vấn (tìm trùng + giữ một dòng), nhận {len(stmts)}"])
            answer = dict(zip(reference.keys(), stmts))
        if not isinstance(answer, dict):
            return CodeGrade(0.0, ["Định dạng bài làm không hợp lệ"])
        parts = {k: (reference[k], contract[k]) for k in reference}
    else:
        if isinstance(answer, dict) or not isinstance(answer, str):
            return CodeGrade(0.0, ["Định dạng bài làm không hợp lệ"])
        parts = {"main": (reference, contract)}
        answer = {"main": answer}

    scores, detail = [], []
    try:
        for key, (ref_sql, ctr) in parts.items():
            student_sql = answer.get(key, "")
            per_dataset = []
            for ds_name, factory in _datasets_for(question_id):
                score, msg = _grade_one_sql(factory, ref_sql, student_sql, ctr)
                per_dataset.append(score)
                detail.append(f"{key}/{ds_name}: {score}/4 - {msg}")
            scores.append(min(per_dataset))
    except GradingError as exc:
        return CodeGrade(0.0, [str(exc)], infrastructure_error=True)
    return CodeGrade(sum(scores) / len(scores), detail)
