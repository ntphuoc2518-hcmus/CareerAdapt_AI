"""roadmap_explainer.py - xem docstring tổng ở __init__.py."""

from __future__ import annotations

import json
import re
from typing import Any, Iterable, Optional

from .config import GradingError, MAX_FORMAT_REPAIRS, MissingDataError
from .llm_layer import LLMClient, ModelConfig, parse_llm_json
from .attempt import AttemptResult
from .module_catalog import Module
from .roadmap import build_roadmap

# --------------------------------------------------------------------------------------
# 16. LLM chỉ GIẢI THÍCH lộ trình đã chốt (mục 4.8)
# --------------------------------------------------------------------------------------

EXPLAIN_SYSTEM_PROMPT = """Bạn viết phần giải thích lộ trình học bằng tiếng Việt cho học viên Data Analyst.
Bạn chỉ được dựa trên dữ liệu chỉ-đọc trong user payload. Bạn KHÔNG được thêm, bớt, đổi thứ tự module,
không được đánh dấu module đã đạt, không được nhắc module_id nào ngoài danh sách selected/deferred.
Trả về MỘT JSON: {"explanation": str, "learning_goals": [1-3 mục tiêu đo được], "deferred_explanations": {module_id: str}}.
Chỉ xuất JSON."""

_MODULE_ID_RE = re.compile(r"\b[A-Z]{2,6}-\d{2}\b")


def roadmap_explanation_input(roadmap: dict) -> dict:
    return {
        "skill_gaps": roadmap["skill_gaps"], "target_score": roadmap["target_score"],
        "selected_modules": [{k: i[k] for k in ("module_id", "title", "hours", "prerequisites", "order")} for i in roadmap["items"]],
        "deferred_modules": [{"module_id": i["module_id"], "title": i["title"], "reason": i["reason"]} for i in roadmap["deferred_items"]],
        "hours_budget": roadmap["hours_budget"], "reliability_flags": roadmap["reliability_flags"],
    }


def validate_explanation(output: Any, roadmap: dict) -> dict:
    """Từ chối đầu ra có module_id không nằm trong selected/deferred hoặc cố sửa lộ trình."""
    if not isinstance(output, dict):
        raise ValueError("Giải thích phải là JSON object")
    if set(output) != {"explanation", "learning_goals", "deferred_explanations"}:
        raise ValueError("Giải thích có khóa thiếu/thừa")
    if not isinstance(output["explanation"], str) or not output["explanation"].strip():
        raise ValueError("explanation phải là chuỗi không rỗng")
    goals = output["learning_goals"]
    if not isinstance(goals, list) or not 1 <= len(goals) <= 3 or not all(isinstance(g, str) and g.strip() for g in goals):
        raise ValueError("learning_goals phải có 1-3 mục là chuỗi")
    deferred_ids = {i["module_id"] for i in roadmap["deferred_items"]}
    selected_ids = {i["module_id"] for i in roadmap["items"]}
    de = output["deferred_explanations"]
    if not isinstance(de, dict) or not set(de) <= deferred_ids or not all(isinstance(v, str) for v in de.values()):
        raise ValueError("deferred_explanations chỉ được chứa module đã bị hoãn")
    allowed = selected_ids | deferred_ids
    texts = [output["explanation"], *goals, *de.values()]
    for text in texts:
        bad = set(_MODULE_ID_RE.findall(text)) - allowed
        if bad:
            raise ValueError(f"Giải thích nhắc module không có trong lộ trình: {sorted(bad)}")
    return output


def explain_roadmap(llm: LLMClient, roadmap: dict, config: Optional[ModelConfig] = None) -> dict:
    config = config or ModelConfig.from_client(llm)
    user = json.dumps(roadmap_explanation_input(roadmap), ensure_ascii=False)
    last = ""
    for _ in range(1 + MAX_FORMAT_REPAIRS):
        raw = llm.complete(EXPLAIN_SYSTEM_PROMPT, user, temperature=config.temperature, max_tokens=config.max_tokens)
        try:
            return validate_explanation(parse_llm_json(raw), roadmap)
        except ValueError as exc:
            last = str(exc)
    raise GradingError(f"Không có giải thích hợp lệ cho lộ trình: {last}")


def build_roadmap_for_attempt(attempt: AttemptResult, catalog: dict[str, Module], hours_per_week: Any, weeks_available: Any,
                              passed_module_ids: Iterable[str] = (), exit_test_results: Optional[dict] = None) -> dict:
    a = attempt.assessment
    if "overall_score" not in a:
        raise MissingDataError("Chưa đủ dữ liệu điểm để xếp lộ trình")
    return build_roadmap(
        audience=attempt.audience, role=attempt.role, skill_scores=attempt.skill_scores, catalog=catalog,
        hours_per_week=hours_per_week, weeks_available=weeks_available, passed_module_ids=passed_module_ids,
        exit_test_results=exit_test_results, focus_skills=a.get("gate_focus_skills", ()) if attempt.audience == "beginner" else (),
        skill_counts=attempt.skill_counts,
        ready_status="not_applicable" if attempt.audience == "beginner" else a["ready_status"])
